// ============================================================================
// Copyright 2017-2019, Schlumberger
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// ============================================================================


#ifndef SDAPI_SDDATASETDISPOSITION_H
#define SDAPI_SDDATASETDISPOSITION_H

namespace seismicdrive {

	/*******************************************************************************//**
	*  
	*  @brief Defines the different Seismic Drive Dataset Dispositions.
	*
	*  This enum defines the different actions
	*  that can be taken when opening a dataset
	*  using seismic drive.
	******************************************************************************/

    enum class SDDatasetDisposition {

		/*******************************************************************************//**
		*  Opens an existing file for reading
		******************************************************************************/
        READ_ONLY,   

		/*******************************************************************************//**
		*  Opens an existing file for reading and writing
		******************************************************************************/
		READ_WRITE,  

		/*******************************************************************************//**
		*  Creates a new file for reading and writing. If the file already exists, it is removed
		******************************************************************************/
		OVERWRITE,  

		/*******************************************************************************//**
		*  Creates a new file for read/write access. If the file already exists, the open fails
		******************************************************************************/
		CREATE       
	};

}

# endif // SDAPI_SDDATASETDISPOSITION_H
