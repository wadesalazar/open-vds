// ============================================================================
// Copyright 2017-2020, Schlumberger
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// ============================================================================

#ifndef SDAPI_SDHIERARCHICALDATASETACCESSOR_H
#define SDAPI_SDHIERARCHICALDATASETACCESSOR_H

#include "DLL_EXPORT.h"
#include "SDDatasetDisposition.h"

#include <iterator>
#include <memory>
#include <string>
#include <vector>

namespace  seismicdrive {

    /*******************************************************************************//**
     * @class SDHierarchicalMetaData SDHierarchicalDatasetAccessor.h
     *
     * @brief This class represents the metadata of a hierarchical dataset.
     * 
     * This class is a struct to store and manage the Hierarchical Dataset Metadata.
     *
    ******************************************************************************/
    struct SDHierarchicalMetaData {

        /*******************************************************************************//**
         * Constructor.
         *
         * @param name is the name of a node of the hierarchical structure.
         * @param nobjects is the number of objects of the node.
         * @param size is the total size of objects of the node.
        ******************************************************************************/
        SDHierarchicalMetaData(const std::string& name="", uint64_t nobjects=0, uint64_t size=0): _name(name), _nobjects(nobjects), _size(size) { }

        /*******************************************************************************//**
        * @brief Comparison Operator.
        *
        *  This operator is used to compare if two SDHierarchicalMetaData objects are identcal.
        * 
        *  @return true if the two SDHierarchicalMetaData objects are the same, flase otherwise.
        * 
        ******************************************************************************/
        bool operator==(const SDHierarchicalMetaData& rhs) {
            return this->_name == rhs._name && this->_nobjects == rhs._nobjects && this->_size == rhs._size;
        }

        //! Name of the node.
        std::string _name;

        //! Number of objects in the node.
        uint64_t _nobjects;

        //! Total size in byte of the object in the node.
        uint64_t _size;
    };

    /*******************************************************************************//**
     * @class SDHierarchicalDatasetAccessor SDHierarchicalDatasetAccessor.h
     *
     * @brief This class allows access to hierarchical datasets in GCS.
     * 
     * This class provide basics methods to read/write blocks of data to GCS.
     *
    ******************************************************************************/
    class DLL_PUBLIC SDHierarchicalDatasetAccessor {

    public:

        /*******************************************************************************//**
         * Constructor.
         *
         * @param disposition is the disposition mode.
         * @param gcsaccessor is the tensorflow GcsAccessor
         * @param gcsUrl is the url of the rooot node in gcs (gs://bucket_name/root_folder)
         * @param tag is an optional tag that can be assigned to the class for debugging purpose
        ******************************************************************************/
        SDHierarchicalDatasetAccessor(const SDDatasetDisposition disposition, void* gcsaccessor, const std::string& gcsUrl, const std::string tag);

        /*******************************************************************************//**
         * Destructor.
         *
         * If the file is opened for writing (not READ_ONLY), it will be closed.
         *
        ******************************************************************************/
        ~SDHierarchicalDatasetAccessor();

        /*******************************************************************************//**
        * @brief Move Constructor.
        *
        *  This contructor moves the SDHierarchicalDatasetAccessor object from 
        *  the source to the new object and destroy the source object. 
        * 
        ******************************************************************************/
        SDHierarchicalDatasetAccessor(SDHierarchicalDatasetAccessor && sdhd) noexcept;

        /*******************************************************************************//**
        * @brief Move Assignment Operator.
        *
        *  Same functionality as the move constructor. 
        * 
        ******************************************************************************/
        SDHierarchicalDatasetAccessor& operator=(SDHierarchicalDatasetAccessor && sdhd) noexcept;

        /*******************************************************************************//**
        * @brief Copy Constructor.
        *
        *  This contructor makes a copy of the SDHierarchicalDatasetAccessor object from 
        *  the source to the new object without modifying the source object. 
        * 
        ******************************************************************************/
        SDHierarchicalDatasetAccessor(const SDHierarchicalDatasetAccessor& op);

        /*******************************************************************************//**
        * @brief Copy Assignment Operator.
        *
        *  Same functionality as the copy constructor. 
        * 
        ******************************************************************************/
        SDHierarchicalDatasetAccessor& operator=(const SDHierarchicalDatasetAccessor& op);

        // --------------------------------------------------------------------------


        /*******************************************************************************//**
         * @brief Return accessor tag.
         * 
         * This method returns the hierarchical dataset accessor's tag.
         * 
         * @return the accessor tag.
         *
        ******************************************************************************/
        std::string get_tag() const;

        /*******************************************************************************//**
         * @brief Adds a new Node 
         * 
         * This method add a new node to the hierarchical structure.
         *
         * @param nodeName is the name of the new node.
         * @return index of the added node in the hierarchical structure.
        ******************************************************************************/
        uint64_t node_add(const std::string& nodeName);

        /*******************************************************************************//**
         * @brief Gets a Node 
         * 
         * This method gets a node from the hierarchical structure.
         *
         * @param nodeName is the name of the new node.
         * @return index of the added node in the hierarchical structure.
        ******************************************************************************/
        uint64_t node_get(const std::string& nodeName) const;

        /*******************************************************************************//**
         * @brief Write an object (block of data/bytes) to gcs.
         *
         * This method writes a block of data (specified with a index of the node) with a specified length.
         * 
         * @param nodeID is the index of the node.
         * @param objectName is the name of the object.
         * @param buffer is the data to write.
         * @param size is the number of byte to write (buffer size).
         *
         * @return the number of bytes written to GCS.
        ******************************************************************************/
        std::size_t object_write(const uint64_t nodeID, const std::string& objectName, const char* buffer, const std::size_t size);

        
        /*******************************************************************************//**
         * @brief Read an object (block of data/bytes) from gcs.
         * 
         * This method reads a block of data (specified with a index of the node) with a specified length.
         *
         * @param nodeID is the index of the node.
         * @param objectName is the name of the object.
         * @param buffer is the buffer where read data will be stored.
         * @param size is the number of byte to read.
        ******************************************************************************/
        void object_read(const uint64_t nodeID,const std::string &objectName, char *buffer, size_t size);

        
        /*******************************************************************************//**
         * @brief Delete an object (block of data/bytes) from gcs.
         * 
         * This method deletes an object from GCS given its name and node index.
         * 
         * @param nodeID is the index of the node.
         * @param objectName is the name of the object.
        ******************************************************************************/
        void object_delete( const uint64_t nodeID, const std::string &objectName );

        // --------------------------------------------------------------------------

        /*******************************************************************************//**
         * @brief gets the node count.
         * 
         * This method is used to get the number of nodes in the current dataset.
         * 
         * @return the number of node currently stored in the hierarchy.
         *
        ******************************************************************************/
        uint64_t node_count() const;

        /*******************************************************************************//**
         * @brief gets the total size of the dataset in bytes.
         * 
         * This method is used to get the total size of the current hierarchical dataset in bytes.
         * 
         * @return the total size in byte of the stored objects.
         *
        ******************************************************************************/
        std::size_t tot_byte_size() const;


        /*******************************************************************************//**
         * @brief gets the metadatas for all stored object.
         * 
         * This method is used to get the metadata of all objects in the current hierarchical dataset in bytes.
         * 
         * @return a vector of metdata for the stored objects.
         *
        ******************************************************************************/
        std::vector<SDHierarchicalMetaData> metadata_get() const;


        /*******************************************************************************//**
         * @brief Adds new metadata 
         * 
         * This method adds new user-defined metadata into the hierarchical dataset structure.
         *
         * @param meta is the metadata to add (must be a JSON::Value).
        ******************************************************************************/
        void metadata_set(void* meta);


        /*******************************************************************************//**
         * @brief gets the names of all the nodes 
         * 
         * This method gets a list of the names of all nodes in the hierarchical dataset.
         * 
         * @return the nodes name list.
         *
        ******************************************************************************/
        std::vector<std::string> node_names() const;


        /*******************************************************************************//**
         * @brief gets the size of all the nodes 
         * 
         * This method gets a list of the sizes of all nodes in the hierarchical dataset in bytes.
         * 
         * @return the nodes size list in bytes.
         *
        ******************************************************************************/
        std::vector<std::size_t> node_sizes() const;


        /*******************************************************************************//**
         * @brief gets the node name.
         * 
         * This method gets the node name given its ID.
         *
         * @param nodeID is the ID of the node.
         * 
         * @return the node name of the passed node ID
        ******************************************************************************/
        std::string node_name(const uint64_t nodeID) const;


        /*******************************************************************************//**
         * @brief gets the node size in bytes.
         * 
         * This method gets the node size given its ID.
         *
         * @param nodeID is the ID of the node.
         * 
         * @return the node size in bytes of the passed node ID
         *          
        ******************************************************************************/
        std::size_t node_size(const uint64_t nodeID) const;


        /*******************************************************************************//**
         * @brief gets the objects count.
         * 
         * This method gets the number of objects in a node given its ID.
         *
         * @param nodeID is the ID of the node.
         * 
         * @return the number of object of the node.
         *
        ******************************************************************************/
        uint64_t object_count(const uint64_t nodeID) const;


        /*******************************************************************************//**
         * @brief gets the objects names.
         * 
         * This method gets the names of objects in a node given its ID.
         *
         * @param nodeID is the ID of the node.
         * 
         * @return a list of the objects names for a given node.
         *
        ******************************************************************************/
        std::vector<std::string> object_names(const uint64_t nodeID) const;


        /*******************************************************************************//**
         * @brief gets the objects sizes.
         * 
         * This method gets the size in byes of all objects in a node given its ID.
         *
         * @param nodeID is the ID of the node.
         * 
         * @return a list of the objects sizes in bytes for a given node.
         * 
        ******************************************************************************/
        std::vector<std::size_t>  object_sizes(const uint64_t nodeID) const;


        /*******************************************************************************//**
         * @brief gets the objects sizes.
         * 
         * This method gets the size in byes of an object in a node given the object name and the node ID.
         *
         * @param nodeID is the ID of the node.
         * @param object_name is the name of the object.
         *          
         * @return the object size in byte for a given node.
         *
        ******************************************************************************/
        std::size_t object_size(const uint64_t nodeID, const std::string &object_name) const;


        /*******************************************************************************//**
         * @brief gets the objects names and sizes.
         * 
         * This method gets the names and sizes of all objects stored in a node given its ID.
         *
         * @param nodeID is the ID of the node.
         * @param names is the vector where the names will be stored.
         * @param sizes is the vector where the sizes will be stored.
         *          
         * @return the objects name and size list in byte for a given node.
         *
        ******************************************************************************/
        void objects_info(const uint64_t nodeID, std::vector<std::string> &names, std::vector<std::size_t> &sizes);

    private:

		#ifdef _MSC_VER
    		#pragma warning(push)
    		#pragma warning(disable: 4251)
		#endif

			class Impl;

			std::unique_ptr<Impl> _impl;

		#ifdef _MSC_VER
    		#pragma warning(pop)
		#endif

        friend class SDHierarchicalDatasetAcsTest;

    };

}

#endif // SDAPI_SDHIERARCHICALDATASETACCESSOR_H
