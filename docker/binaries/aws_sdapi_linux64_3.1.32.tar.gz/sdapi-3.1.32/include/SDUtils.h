// ============================================================================
// Copyright 2017-2020, Schlumberger
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// ============================================================================

#ifndef SDAPI_SDUTILS_H
#define SDAPI_SDUTILS_H

#include "DLL_EXPORT.h"

#include <string>
#include <vector>

#include "SDManager.h"

namespace seismicdrive {

    /*******************************************************************************//**
     * @class SDUtils SDUtils.h
     *
     * @brief Seismic Drive Utilities class.
     * 
     * This class is the utilities class for the seismic-drive namespace.
     *
    ******************************************************************************/
   
    class DLL_PUBLIC SDUtils {

    public:

   	    /*******************************************************************************//**
         * @brief Constructor.
         *
         * @param sdmanager is the seismic drive service manager
         *
        ******************************************************************************/
        SDUtils(SDManager* sdmanager);

        /*******************************************************************************//**
         * Destructor.
         *
         * If the file is opened for writing (not READ_ONLY), it will be closed.
         *
        ******************************************************************************/
        ~SDUtils();

        /*******************************************************************************//**
        * @brief Move Constructor.
        *
        *  This contructor moves the SDUtils object from 
        *  the source to the new object and destroy the source object. 
        * 
        ******************************************************************************/
        SDUtils(SDUtils &&rhf) noexcept;

        /*******************************************************************************//**
        * @brief Move Assignment Operator.
        *
        *  Same functionality as the move constructor. 
        * 
        ******************************************************************************/
        SDUtils &operator=(SDUtils &&rhf) noexcept;

        /*******************************************************************************//**
        * @brief Copy Constructor.
        *
        *  This contructor makes a copy of the SDUtils object from 
        *  the source to the new object without modifying the source object. 
        * 
        ******************************************************************************/
        SDUtils(const SDUtils &rhs);

        /*******************************************************************************//**
        * @brief Copy Assignment Operator.
        *
        *  Same functionality as the copy constructor. 
        * 
        ******************************************************************************/
        SDUtils &operator=(const SDUtils &rhs);

        /*******************************************************************************//**
         * @brief Checks for existance of several files. 
         * 
         * This method checks if a list of filenames exists on GCP. 
         * This is much faster than checking each file name separately
         *
         * @param sdfileNames list of dataset path ( sd://tenant/subproject/path/dataset ).
         * All sdfileNames must refer to the same subproject (must have the same sd://tenant/subproject prefix)
         * 
         * @return a vector boolean (true if the dataset exists false if not)
         ******************************************************************************/
        std::vector<bool> datasetsExist(const std::vector <std::string> &sdfileNames);

        /*******************************************************************************//**
         * @brief Checks for existance of a file. 
         * 
         * This method checks if a single file exists on GCP.
         * This is much slower per file than checking all file names together.
         *
         * @param fileName name of file to check ( sd://tenant/subproject/path/dataset )
         * 
         * @return true if file exists
         ******************************************************************************/
        bool datasetExist(const std::string &fileName);

        /*******************************************************************************//**
         * @brief Get the file size in bytes of several files. 
         * 
         * This method gets the size of a list of datasets in bytes. 
         * The method returns 0 for files that do not exist.
         *
         * @param sdfileNames list of dataset path ( sd://tenant/subproject/path/dataset )
         * All sdfileNames must refer to the same subproject (must have the same sd://tenant/subproject prefix)
         * 
         * @return a vector with the required datasets sizes
         ******************************************************************************/
        std::vector<int64_t> datasetsSize(const std::vector <std::string> &sdfileNames);

        /*******************************************************************************//**
         * @brief Get the file size in bytes. 
         * 
         * This method gets the size in bytes of one signle dataset.
         * This method returns 0 if file does not exist.
         *
         * @param fileName name of file to get size ( sd://tenant/subproject/path/dataset )
         * 
         * @return 64 bit integer size in bytes
         ******************************************************************************/
        int64_t datasetSize(const std::string &fileName);

        /*******************************************************************************//**
         * @brief Delete a dataset
         * 
         * This method is used to delete a dataset given its full path name.
         *
         * @param sddatasetname is the seismic drive dataset name ( sd://tenant/subproject/path/dataset )
         ******************************************************************************/
        void deleteDataset(const std::string &sddatasetname);

        /*******************************************************************************//**
         * @brief Determines whether a block of data exists in a dataset.
         * 
         * This method determines whether a block of data (specified with a block number) exists in a dataset.
         * 
         * @param datasetpath is the seismic drive dataset name ( sd://tenant/subproject/path/dataset )
         *
         * @param blocknum is the number of the block
         *
         * @return true if the block exists, otherwise false.
        ******************************************************************************/
		bool blockExists(const std::string& datasetpath, int blocknum) const;

        /*******************************************************************************//**
         * @brief Determines whether a block of data exists in a dataset.
         * 
         * This method determines whether a block of data (specified with a block number) exists in a dataset.
         *
         * @param datasetpath is the seismic drive dataset name ( sd://tenant/subproject/path/dataset )
         *
         * @param blockname is the name of the block
         *
         * @return true if the block exists, otherwise false.
        ******************************************************************************/
		bool blockExists(const std::string& datasetpath, const std::string &blockname) const;

        /*******************************************************************************//**
         * @brief List Datasets and directories in a directory
         * 
         * This method return a list of files and folders in a given full path directory.
         *
         * @param sddirectorypath is the seismic drive direcoty path ( sd://tenant/subproject/path )
         * 
         * @return a list of the list of names in the directory
         ******************************************************************************/
        std::vector<std::vector<std::string>> readDirectory(const std::string &sddirectorypath) const;

        /*******************************************************************************
         * @brief Upload a file
         *
         * This method can be used to upload a file into a single object
         *
         * prerequisites:
         * The dataset must not been open
         * File to upload must exist
         *
         * usage example:

         * - std::string fileToUpload = "/path/to/your.file"
         * - std::ifstream infile(fileToUpload);
         * - if(!infile.good())
         * -    return 0
         *
         * - SDManager sdmanager;
         * - SDUtils utils(&sdmanager);
         * - utils.upload("sd://tenant/subproject/path/your.file", fileToUpload);
         *
         * @param datasetpath is the seismic drive dataset name ( sd://tenant/subproject/path/dataset )
         * @param filename is the path of the file to upload
         *
         * failure mode:
         * @throw seismicdrive::SDExceptionDatasetError if dataset is currently open
         ******************************************************************************/
        void upload(const std::string& datasetpath, const std::string& filename) const;

        /*******************************************************************************//**
         * @brief Check if a dataset path is a valid seismic-store dataset path
         * 
         * This method checks if a given sd path exits on GCP.
         *
         * @param datasetpath is the seismic-store dataset path to validate
         * 
         * @return true if the path exists, and false if it does not
         *
         */
        static bool isSDDatasetPath(const std::string& datasetpath);

        /*******************************************************************************//**
         * @brief Get dataset created date
         *
         * This method can be used to retrieve the dataset creation date.
         *
         * usage example:
         *
         * - SDManager sdmanager;
         * - SDUtils utils(&sdmanager);
         * - auto cdate = utils.getCreatedDate("sd://tenant/subproject/data");
         * 
         * @param seistoreDatasetPath is the seismic-store dataset path
         *
         * @return The dataset created date
         ******************************************************************************/
        std::string getCreatedDate(const std::string& seistoreDatasetPath) const;

        /*******************************************************************************//**
         * @brief Get dataset last modified date
         *
         * This method can be used to retrieve the dataset last modified date.
         *
         * usage example:
         *
         * - SDManager sdmanager;
         * - SDUtils utils(&sdmanager);
         * - auto cdate = utils.getLastModifiedDate("sd://tenant/subproject/data");
         * 
         * @param seistoreDatasetPath is the seismic-store dataset path
         *
         * @return The dataset last modified date
         ******************************************************************************/
        std::string getLastModifiedDate(const std::string& seistoreDatasetPath) const;

        /*******************************************************************************//**
         * @brief Get dataset "create by"
         *
         * This method can be used to retrieve the "created by" field associated with a dataset.
         *
         * usage example:
         *
         * - SDManager sdmanager;
         * - SDUtils utils(&sdmanager);
         * - auto createdby = utils.getCreatedBy("sd://tenant/subproject/data");
         * 
         * @param seistoreDatasetPath is the seismic-store dataset path
         *
         * @return The dataset created by field
         ******************************************************************************/
        std::string getCreatedBy(const std::string& seistoreDatasetPath) const;

        /*******************************************************************************//**
         * @brief Get dataset type
         *
         * This method can be used to retrieve the dataset type associated with a dataset.
         *
         * usage example:
         *
         * - SDManager sdmanager;
         * - SDUtils utils(&sdmanager);
         * - auto type = utils.getType("sd://tenant/subproject/data");
         * 
         * @param seistoreDatasetPath is the seismic-store dataset path
         *
         * @return the dataset type.
        ******************************************************************************/
        std::string getType(const std::string& seistoreDatasetPath) const;

        /*******************************************************************************//**
         * @brief Get dataset legal-tag.
         *
         * This method can be used to retrieve the dataset type associated with a dataset.
         *
         * usage example:
         *
         * - SDManager sdmanager;
         * - SDUtils utils(&sdmanager);
         * - auto legalTag = utils.getLegalTag("sd://tenant/subproject/data");
         * 
         * @param seistoreDatasetPath is the seismic-store dataset path
         *
         * @return the dataset legal-tag.
        ******************************************************************************/
        std::string getLegalTag(const std::string& seistoreDatasetPath) const;

        /*******************************************************************************//**
         * @brief Unlock a dataset
         *
         * This method can be used to unlock a dataset in seismic store
         *
         * usage example:
         *
         * - SDManager sdmanager;
         * - SDUtils utils(&sdmanager);
         * - utils.datasetUnlock("sd://tenant/subproject/data");
         * 
         * @param seistoreDatasetPath is the seismic-store dataset path
         *
         ******************************************************************************/
        void datasetUnlock(const std::string& seistoreDatasetPath) const;

        /*******************************************************************************//**
         * @brief Get the dataset open session id
         *
         * This method can be used to get the dataset open session id.
         * 
         * usage example:
         *
         * - SDManager sdmanager;
         * - SDUtils utils(&sdmanager);
         * - utils.getOpenSessionID("sd://tenant/subproject/data");
         * 
         * @param seistoreDatasetPath is the seismic-store dataset path
         *
         *  @return 
         *      The dataset open status ID. "R" if the dataset has been opened for read, 
         *      "WID" if the dataset has been opened for write, empty string if the dataset is closed.
         ******************************************************************************/
        std::string getOpenSessionID(const std::string& seistoreDatasetPath) const;

    private:

		#ifdef _MSC_VER
    		#pragma warning(push)
    		#pragma warning(disable: 4251)
		#endif

			class Impl;

			std::unique_ptr<Impl> _impl;

		#ifdef _MSC_VER
		    #pragma warning(pop)
		#endif

        friend class SDUtilsTest;

    };

}

#endif //SDAPI_SDUTILS_H
