// ============================================================================
// Copyright 2017-2020, Schlumberger
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// ============================================================================


#ifndef SDAPI_SDHIERARCHICALDATASET_H
#define SDAPI_SDHIERARCHICALDATASET_H

#include "DLL_EXPORT.h"
#include "SDDatasetDisposition.h"
#include "SDHierarchicalDatasetAccessor.h"
#include "SDManager.h"

#include <unordered_map>
#include <memory>

namespace seismicdrive {

    struct HttpContext;

    /*******************************************************************************//**
     * @class SDHierarchicalDataset SDHierarchicalDataset.h
     *
     * @brief This class represents a hierarchical dataset object in GCP.
     * 
     * This class is a hierarchical Dataset class to read/write gcs objects with a hierarchical structure.
     *
    ******************************************************************************/
   

    class DLL_PUBLIC SDHierarchicalDataset {

    public:

        /*******************************************************************************//**
         * @brief Constructor.
         *
         * @param sdmanager is the seismic drive service manager
         * @param sdfilename name of the dataset. It must be in the form /seimsic-drive/[tenant_name]/[subproject_name]/[path*]/[dataset_name].
         * The field [path*] rapresent the logic dataset hierarchy and it's optional. example sd://fatty-acid/sproj01/a/b/c/dataset_01
         * @param log is a boolean value that enable the debug logger (false by default)
        ******************************************************************************/
        SDHierarchicalDataset(SDManager* sdmanager, const std::string &sdfilename, const bool log = false);

        /*******************************************************************************//**
         * @brief Constructor with dataset type.
         *
         * @param sdmanager is the seismic drive service manager
         * @param sdfilename name of the dataset. It must be in the form /seimsic-drive/[tenant_name]/[subproject_name]/[path*]/[dataset_name].
         * The field [path*] rapresent the logic dataset hierarchy and it's optional. example sd://fatty-acid/sproj01/a/b/c/dataset_01
         * @param filetype is the dataset type (ex. dio, bolt, txt, segy... )
         * @param log is a boolean value that enable the debug logger (false by default)
        ******************************************************************************/
        SDHierarchicalDataset(SDManager* sdmanager, const std::string &sdfilename, const std::string& filetype, const bool log = false);


        /*******************************************************************************//**
         * @brief Destructor.
         *
         * If the file is opened for writing (not READ_ONLY), it wll be closed.
        ******************************************************************************/
        ~SDHierarchicalDataset();

        /*******************************************************************************//**
        * @brief Move Constructor.
        *
        *  This contructor moves the SDHierarchicalDataset object from 
        *  the source to the new object and destroy the source object. 
        * 
        ******************************************************************************/
        SDHierarchicalDataset(SDHierarchicalDataset &&sdhd) noexcept;

        /*******************************************************************************//**
        * @brief Move Assignment Operator.
        *
        *  Same functionality as the move constructor. 
        * 
        ******************************************************************************/
        SDHierarchicalDataset &operator=(SDHierarchicalDataset &&sdhd) noexcept;

        /*******************************************************************************//**
        * @brief Copy Constructor.
        *
        *  This contructor makes a copy of the SDHierarchicalDataset object from 
        *  the source to the new object without modifying the source object. 
        * 
        ******************************************************************************/
        SDHierarchicalDataset(const SDHierarchicalDataset &op);

        /*******************************************************************************//**
        * @brief Copy Assignment Operator.
        *
        *  Same functionality as the copy constructor. 
        * 
        ******************************************************************************/
        SDHierarchicalDataset &operator=(const SDHierarchicalDataset &op);

        /*******************************************************************************//**
         * @brief Opens the dataset whose name was specified the constructor.
         *  
         * This method is the most basic open function. It opens a dataset with a given open mode.
         * 
         * usage example:
         *
         * - SDManager sdmanager;
         * - SDGenericDataset dataset(&sdmanager, "sd://tenant/subproject/data");
         * - dataset.open(SDDatasetDisposition::CREATE);
         * - dataset.close();
         * 
         * @param disposition open mode
         *
        ******************************************************************************/
        void open(const SDDatasetDisposition disposition);

        /*******************************************************************************//**
         * @brief Opens the dataset whose name was specified the constructor.
         * 
         * This method allows opening a dataset with a given open mode and legaltag.
         * 
         * usage example:
         *
         * - SDManager sdmanager;
         * - SDGenericDataset dataset(&sdmanager, "sd://tenant/subproject/data");
         * - dataset.open(SDDatasetDisposition::CREATE, {
         *                      {seismicdrive::api::json::Constants::kLegalTagLabel, "legal-tag"});
         * - dataset.close();
         * 
         * @param disposition open mode
         * @param legaltag the dataset legaltag
         *
        ******************************************************************************/
        void open(const SDDatasetDisposition disposition, const std::string& legaltag);

        /*******************************************************************************//**
         * @brief Opens the dataset whose name was specified the constructor.
         * 
         * This method allows opening a dataset with a given open mode and legaltag that has already been locked for writing.
         * 
         * usage example:
         *
         * - SDManager sdmanager;
         * - SDGenericDataset dataset(&sdmanager, "sd://tenant/subproject/data");
         * - dataset.open(SDDatasetDisposition::CREATE, {
         *                      {seismicdrive::api::json::Constants::kLegalTagLabel, "legal-tag"},
         *                      {seismicdrive::api::json::Constants::kWriteIdLabel, "wid"});
         * - dataset.close();
         *
         * @param disposition open mode
         * @param wid is the write opening id. This must be specified if you wnat to open a dataset already locked for write.
         * @param legaltag the dataset legaltag
        ******************************************************************************/
        void open(const SDDatasetDisposition disposition, const std::string& legaltag, const std::string& wid);

        
        /*******************************************************************************//**
         * @brief Main method to open a seismic store dataset
         *
         * This method opens a seismic data dataset in seismic store.
         *
         * The method support different opening dispotion modes:
         *
         *  - CREATE: create a dataset and open it for write
         *  - OVERWRITE: create a dataset and open it for write overriding the existing one.
         *  - READ_WRITE: open an existing dataset for read and write.
         *  - READ_ONLY: open an existing dataset for read only.
         *
         * The method accepts these optional opening arguments (defined in Constants.h);
         *
         *  - kLegalTagLabel: the legal tag,
         *  - kWriteIdLabel: the open write seission id
         *  - kDDMSSeismicMetadataLabel: the seismic storage metadata.
         *  - KPedantic: the pedantic working mode. 
         *               - "enable": the file-metadata, if exist, will be saved automatically during the close. 
         *               - "disable" the file-metadata, if exist, will not be automatically saved during the close.
         * 
         * usage example:
         *
         * - SDManager sdmanager;
         * - SDGenericDataset dataset(&sdmanager, "sd://tenant/subproject/data");
         * - dataset.open(SDDatasetDisposition::CREATE, {
         *                      {seismicdrive::api::json::Constants::kLegalTagLabel, "legal-tag"},
         *                      {seismicdrive::api::json::Constants::kWriteIdLabel, "wid"},
         *                      {seismicdrive::api::json::Constants::kDDMSSeismicMetadataLabel, "{\"data\":\"value\"}"}
         *                      {seismicdrive::api::json::Constants::kPedantic, "enable" || "disable"} });
         * - dataset.close();
         *
         * @param disposition The opening disposition open mode
         * @param args The list of optional arguments
         ******************************************************************************/
        void open(const SDDatasetDisposition disposition, const std::unordered_map<std::string, std::string> &args);


        /*******************************************************************************//**
         * @brief Close an opened dataset.
         * 
         * This method closes a dataset and marks it as closed. File must be opened.
         *
        ******************************************************************************/
        void close();

        /*******************************************************************************//**
         * @brief Flushes the file metadata
         * 
         * This method flushes the metadata of the object into the dataset.
         *
        ******************************************************************************/
        void flush();

        /*******************************************************************************//**
         * @brief Checks if the dataset exist
         *
         * This method checks if the created dataset exists on GCP.
         * 
         * @return true if the dataset exist, false if it does not exist
         *
        ******************************************************************************/
        bool exist() const;

        /*******************************************************************************//**
         * @brief Return the dataset opening state
         * 
         * This method return whether or not a dataset is already opened.
         *
         * @return true if the dataset is opened, false if not
        ******************************************************************************/
        bool isOpen();

        /*******************************************************************************//**
        * @brief Checks if an object exists
        * 
        * This method checks if an object exists on GCP in a certain path. 
        *
        * @param gcs_path is the gcs URI of the resource
        * 
        * @return true if tge object exists, false if the object not exist
        ******************************************************************************/
        bool objectExists(const std::string &gcs_path) const;

        /*******************************************************************************//**
         * @brief gets the hierarchical dataset accessor
         * 
         * This method generates an accessor for the current hierarchical dataset.
         *
         * @return the Hierarchical Dataset Accessor.
        ******************************************************************************/
        SDHierarchicalDatasetAccessor getDatasetAccessor() const;

        /*******************************************************************************//**
         * @brief Merges the accessor metadata into the dataset.
         * 
         * This method merges the metadata of a Hierarchical Dataset Accessor into the Hierarchical Dataset.
         *
         * @param dsaccessor is the Hierarchical Dataset Accessor
        ******************************************************************************/
        void mergeDatasetAccessor(const SDHierarchicalDatasetAccessor &dsaccessor);

        /*******************************************************************************//**
         * @brief Acquire a lockfile on the dataset
         * 
         * This methos locks the current dataset.
        ******************************************************************************/
        void lock();

        /*******************************************************************************//**
         * @brief Wait until lockfile on the dataset is removed
         * 
         * This method waits until the current dataset is not locked by another process.
        ******************************************************************************/
        void waitLock();

        /*******************************************************************************//**
         * @brief Release a lockfile on the dataset
         * 
         * This method removes the lock from the current dataset.
        ******************************************************************************/
        void unlock();

        /*******************************************************************************//**
         * @brief Gets the locking session id
         * 
         * This method is an accessor used to get the locking session ID of the current dataset.
         *
         * @return the locking id
        ******************************************************************************/
        std::string getConsistencyID();

        /*******************************************************************************//**
         * @brief Gets process number that is locking the dataset
         * 
         * This method is an accessor used to get the process number that is locking the current dataset.
         *              
         * @return the consistency process counter
        ******************************************************************************/
        int getConsistencyCounter();

        /*******************************************************************************//**
         * @brief Add dataset tags
         *
         * This method can be used to set a list of tags to a seismic store dataset.
         * Tags are just simple strings (not key/value pairs).
         *
         * usage example:
         *
         * - SDManager sdmanager;
         * - SDGenericDataset dataset(&sdmanager, "sd://tenant/subproject/data");
         * - dataset.open(SDDatasetDisposition::READ_WRITE);
         * - dataset.setTags({"TestTag01", "TestTag02", "TestTag03"});
         * - dataset.close();
         *
         * @param tags The list of tags to add to the opened seismic store dataset
         ******************************************************************************/
		void setTags(const std::vector<std::string>& tags) const;

        /*******************************************************************************//**
         * @brief Get dataset tags
         *
         * This method can be used to retrieve the list of seismic store dataset tags.
         *
         * usage example:
         *
         * - SDManager sdmanager;
         * - SDGenericDataset dataset(&sdmanager, "sd://tenant/subproject/data");
         * - dataset.open(SDDatasetDisposition::READ_ONLY);
         * - auto tags = dataset.getTags();
         * - dataset.close();
         *
         * @return The list of seismic store dataset tags
         ******************************************************************************/
		std::vector<std::string> getTags() const;

        /*******************************************************************************//**
         * @brief Gets the legal-tag.
         * 
         * This method gets the legal-tag.
         *
         * @return the legal-tag.
        ******************************************************************************/
        std::string getLegalTag() const;

        /*******************************************************************************//**
         * @brief Get dataset created date
         *
         * This method can be used to retrieve the dataset creation date.
         *
         * usage example:
         *
         * - SDManager sdmanager;
         * - SDGenericDataset dataset(&sdmanager, "sd://tenant/subproject/data");
         * - dataset.open(SDDatasetDisposition::READ_ONLY);
         * - auto cdate = dataset.getCreatedDate();
         * - dataset.close();
         *
         * @return The dataset created date
         ******************************************************************************/
        std::string getCreatedDate() const;

        /*******************************************************************************//**
         * @brief Gets the dataset type.
         * 
         * This method gets the dataset type.
         *
         * @return the dataset type.
        ******************************************************************************/
        std::string getType() const;

        /*******************************************************************************//**
         * @brief Add seismic metadata to the dataset
         * This method can be use to set the seismic metadata field in the dataset's JSON
         *
         * usage example:
         *
         * SDManager sdmanager;
         * SDHierarchicalDataset dataset(&sdmanager, "sd://tenant/subproject/data");
         * dataset.open(SDDatasetDisposition::READ_WRITE);
         * dataset.setSeismicMeta("{\"description\":\"\"}");
         * dataset.close();
         *
         * @param seismicmeta is the json stringify seismic metadata. The schema for seismic meta can be found at https://developer.delfi.slb.com/solutions/dataecosystem/tutorials/storageservice
         *
         * @throw SDExceptionDatasetError Invalid JSON or seismic meta field does not exist after patch request
        ******************************************************************************/
        void setSeismicMeta(const std::string &seismicmeta);

        /*******************************************************************************//**
         * @brief Get the seismic metadata from the dataset
         *
         * This method can be used to retrieve the seismic metadata field from the dataset's JSON
         *
         * usage example:
         *
         * SDManager sdmanager;
         * SDHierarchicalDataset dataset(&sdmanager, "sd://tenant/subproject/data");
         * dataset.open(SDDatasetDisposition::READ_ONLY);
         * auto smeta = dataset.getSeismicMeta();
         * dataset.close()
         *
         * @return the stringify json seismic metadata
        ******************************************************************************/
        std::string getSeismicMeta() const;

        /*******************************************************************************//**
         * @brief Set connection parameters
         *
         * This method sets connection parameters for the underlying HTTP connection 
         * to the server.
         *
         * @param context The connection parameters to be used for this dataset
         * 
         * usage example:
         *
         * HttpContext context;
         * context.timeoutSecs = 3600;
         * context.tcpKeepAlive = true;
         * 
         * SDManager sdmanager;
         * SDHierarchicalDataset dataset(&sdmanager, "sd://tenant/subproject/data");
         * dataset.setHttpContext(&context);
         * dataset.open(SDDatasetDisposition::READ_ONLY);
         * auto smeta = dataset.getSeismicMeta();
         * dataset.close()
         *
         ******************************************************************************/
		void setHttpContext(const HttpContext *context = nullptr);

    private:

		#ifdef _MSC_VER
    		#pragma warning(push)
    		#pragma warning(disable: 4251)
		#endif

			class Impl;

			std::unique_ptr<Impl> _impl;

		#ifdef _MSC_VER
    		#pragma warning(pop)
		#endif

        friend class SDHierarchicalDatasetTest;

    };

}

#endif // SDAPI_SDHIERARCHICALDATASET_H
