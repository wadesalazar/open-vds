// ============================================================================
// Copyright 2017-2020, Schlumberger
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// ============================================================================


#ifndef SDAPI_SDGENERICDATASET_H
#define SDAPI_SDGENERICDATASET_H

#include "DLL_EXPORT.h"
#include "SDDatasetDisposition.h"
#include "SDManager.h"

#include <unordered_map>
#include <memory>
#include <vector>

namespace seismicdrive {

    struct HttpContext;

    /*******************************************************************************//**
     * @class SDGenericDatasetBasicObjectInfo SDGenericDataset.h
     *
     * @brief This class holds generic dataset object info.
     * 
     * This class stores general information about the dataset: 
     * the name and size of the dataset.
     *
    ******************************************************************************/
    class DLL_PUBLIC SDGenericDatasetBasicObjectInfo {

    public:

        /*******************************************************************************//**
        * @brief Default constructor.
        *
        *  This contructor creates a SDGenericDatasetBasicObjectInfo object and 
        *  initialize its name and size. 
        * 
        ******************************************************************************/
        SDGenericDatasetBasicObjectInfo();


        /*******************************************************************************//**
        * @brief Destructor.
        *
        *  This destructor deletes the SDGenericDatasetBasicObjectInfo object and 
        *  free up the memory after it goes out of scope. 
        * 
        ******************************************************************************/
        ~SDGenericDatasetBasicObjectInfo();


        /*******************************************************************************//**
        * @brief Move Constructor.
        *
        *  This contructor moves the SDGenericDatasetBasicObjectInfo object from 
        *  the source to the new object and destroy the source object. 
        * 
        ******************************************************************************/
        SDGenericDatasetBasicObjectInfo(SDGenericDatasetBasicObjectInfo &&rhs) noexcept;


        /*******************************************************************************//**
        * @brief Move Assignment Operator.
        *
        *  Same functionality as the move constructor. 
        * 
        ******************************************************************************/
        SDGenericDatasetBasicObjectInfo &operator=(SDGenericDatasetBasicObjectInfo &&rhs) noexcept;


        /*******************************************************************************//**
        * @brief Copy Constructor.
        *
        *  This contructor makes a copy of the SDGenericDatasetBasicObjectInfo object from 
        *  the source to the new object without modifying the source object. 
        * 
        ******************************************************************************/
        SDGenericDatasetBasicObjectInfo(const SDGenericDatasetBasicObjectInfo &rhs);


        /*******************************************************************************//**
        * @brief Copy Assignment Operator.
        *
        *  Same functionality as the copy constructor. 
        * 
        ******************************************************************************/
        SDGenericDatasetBasicObjectInfo &operator=(const SDGenericDatasetBasicObjectInfo &rhs);


        /*******************************************************************************//**
        * @brief Gets the name of a SDGenericDatasetBasicObjectInfo object 
        *
        *  This method is an accessor used to get the name of a SDGenericDatasetBasicObjectInfo object   
        *
        *  @return the name of the SDGenericDatasetBasicObjectInfo object
        ******************************************************************************/
        std::string getName() const;


        /*******************************************************************************//**
        * @brief Gets the size of a SDGenericDatasetBasicObjectInfo object 
        *
        *  This method is an accessor used to get the size of a SDGenericDatasetBasicObjectInfo object   
        *
        *  @return the size of the SDGenericDatasetBasicObjectInfo object
        ******************************************************************************/
        long long getSize() const;

        
        /*******************************************************************************//**
        * @brief Sets the name of a SDGenericDatasetBasicObjectInfo object 
        *
        *  This method is a mutator used to set the name of a SDGenericDatasetBasicObjectInfo object   
        * 
        *  @param objname is the object name
        *  @return Void
        ******************************************************************************/
        void setName(const std::string& objname);

        
        /*******************************************************************************//**
        * @brief Sets the size of a SDGenericDatasetBasicObjectInfo object 
        *
        *  This method is a mutator used to set the size of a SDGenericDatasetBasicObjectInfo object   
        * 
        *  @param objsize is the object size
        *  @return Void
        ******************************************************************************/
        void setSize(long long objsize);


    private:

		#ifdef _MSC_VER
    		#pragma warning(push)
    		#pragma warning(disable: 4251)
		#endif

			class Impl;

			std::unique_ptr<Impl> _impl;

		#ifdef _MSC_VER
		    #pragma warning(pop)
		#endif

	};


	/*******************************************************************************//**
     * @class SDGenericDatasetBasicObjectIterator SDGenericDataset.h
     *
     * @brief This class is a generic Dataset class object iterator
     * 
     * This class is an iterator used to iterate through SDGenericDatasetBasicObjectInfo objects.
     *
    ******************************************************************************/
    class DLL_PUBLIC SDGenericDatasetBasicObjectIterator {

    public:

        /*******************************************************************************//**
        * @brief Default constructor.
        *
        *  This contructor creates a SDGenericDatasetBasicObjectIterator object and 
        *  initialize whether it has a next SDGenericDatasetBasicObjectInfo object. 
        * 
        ******************************************************************************/
        SDGenericDatasetBasicObjectIterator();

       
        /*******************************************************************************//**
        * @brief Destructor.
        *
        *  This destructor deletes the SDGenericDatasetBasicObjectIterator object and 
        *  free up the memory after it goes out of scope. 
        * 
        ******************************************************************************/
        ~SDGenericDatasetBasicObjectIterator();

        
        /*******************************************************************************//**
        * @brief Move Constructor.
        *
        *  This contructor moves the SDGenericDatasetBasicObjectIterator object from 
        *  the source to the new object and destroy the source object. 
        * 
        ******************************************************************************/
        SDGenericDatasetBasicObjectIterator(SDGenericDatasetBasicObjectIterator &&rhs) noexcept;

        
        /*******************************************************************************//**
        * @brief Move Assignment Operator.
        *
        *  Same functionality as the move constructor. 
        * 
        ******************************************************************************/
        SDGenericDatasetBasicObjectIterator &operator=(SDGenericDatasetBasicObjectIterator &&rhs) noexcept;

        
        /*******************************************************************************//**
        * @brief Copy Constructor.
        *
        *  This contructor makes a copy of the SDGenericDatasetBasicObjectIterator object from 
        *  the source to the new object without modifying the source object. 
        * 
        ******************************************************************************/
        SDGenericDatasetBasicObjectIterator(const SDGenericDatasetBasicObjectIterator &rhs);

        
        /*******************************************************************************//**
        * @brief Copy Assignment Operator.
        *
        *  Same functionality as the copy constructor. 
        * 
        ******************************************************************************/
        SDGenericDatasetBasicObjectIterator &operator=(const SDGenericDatasetBasicObjectIterator &rhs);

        
        /*******************************************************************************//**
        * @brief Checks if more SDGenericDatasetBasicObjectInfo objects are available 
        *
        *  This method checks to see if the current SDGenericDatasetBasicObjectInfo
        *  has a following object of the name type.   
        *
        *  @return true if the object has a next object and 
        *          false if the current object is the last one
        ******************************************************************************/
        bool hasNext();


        /*******************************************************************************//**
        * @brief Returns the next SDGenericDatasetBasicObjectInfo object 
        *
        *  This method creates a new SDGenericDatasetBasicObjectInfo object, assigns
        *  its name and size from the next object and return that object that is a copy
        *  from the next object.   
        *
        *  @return the next SDGenericDatasetBasicObjectInfo object that follows
        *          the current object if it exists.
        ******************************************************************************/
        SDGenericDatasetBasicObjectInfo next();

    private:

        friend class SDGenericDataset;
        friend class SDGenericDatasetTest;

		#ifdef _MSC_VER
    		#pragma warning(push)
    		#pragma warning(disable: 4251)
		#endif

			class Impl;

			std::unique_ptr<Impl> _impl;

		#ifdef _MSC_VER
    		#pragma warning(pop)
		#endif

    };


   	/*******************************************************************************//**
     * @class SDGenericDataset SDGenericDataset.h
     *
     * @brief This class represents a generic dataset in GCP.
     * 
     * This class is a generic Dataset class to to read/write gcs objects as sequential(0...n-1) file blocks.
     *
    ******************************************************************************/
    class DLL_PUBLIC SDGenericDataset {

    public:

   	    /*******************************************************************************//**
         * @brief Constructor.
         *
         * @param sdmanager is the seismic drive service manager
         * @param sdfilename name of the dataset. It must be in the form /seimsic-drive/[tenant_name]/[subproject_name]/[path*]/[dataset_name]. The field [path*] rapresent the dataset hierarchy and it's optional. example sd://fatty-acid/sproj01/a/b/c/dataset_01
         * @param log is a boolean value that enable the debug logger (false by default)
         *
        ******************************************************************************/
        SDGenericDataset(SDManager* sdmanager, const std::string &sdfilename, const bool log = false);

   	    
        /*******************************************************************************//**
         * @brief Constructor with dataset type.
         *
         * @param sdmanager is the seismic drive service manager
         * @param sdfilename name of the dataset. It must be in the form /seimsic-drive/[tenant_name]/[subproject_name]/[path*]/[dataset_name]. The field [path*] rapresent the dataset hierarchy and it's optional. example sd://fatty-acid/sproj01/a/b/c/dataset_01
         * @param filetype is the dataset type (ex. dio, bolt, txt, segy... )
         * @param log is a boolean value that enable the debug logger (false by default)
         *
        ******************************************************************************/
        SDGenericDataset(SDManager* sdmanager, const std::string &sdfilename, const std::string& filetype, const bool log = false);

        
        /*******************************************************************************//**
         * @brief Destructor.
         *
         * If the file is opened for writing (not READ_ONLY), it will be closed.
         *
        ******************************************************************************/
        ~SDGenericDataset();


        /*******************************************************************************//**
        * @brief Move Constructor.
        *
        *  This contructor moves the SDGenericDataset object from 
        *  the source to the new object and destroy the source object. 
        * 
        ******************************************************************************/
        SDGenericDataset(SDGenericDataset &&rhs) noexcept;

        
        /*******************************************************************************//**
        * @brief Move Assignment Operator.
        *
        *  Same functionality as the move constructor. 
        * 
        ******************************************************************************/
        SDGenericDataset &operator=(SDGenericDataset &&rhs) noexcept;

        
        /*******************************************************************************//**
        * @brief Copy Constructor.
        *
        *  This contructor makes a copy of the SDGenericDataset object from 
        *  the source to the new object without modifying the source object. 
        * 
        ******************************************************************************/
        SDGenericDataset(const SDGenericDataset &rhs);

        
        /*******************************************************************************//**
        * @brief Copy Assignment Operator.
        *
        *  Same functionality as the copy constructor. 
        * 
        ******************************************************************************/
        SDGenericDataset &operator=(const SDGenericDataset &rhs);

        
        /*******************************************************************************//**
         * @brief Opens the dataset whose name was specified the constructor.
         *  
         * This method is the most basic open function. It opens a dataset with a given open mode.
         * 
         * usage example:
         *
         * - SDManager sdmanager;
         * - SDGenericDataset dataset(&sdmanager, "sd://tenant/subproject/data");
         * - dataset.open(SDDatasetDisposition::CREATE);
         * - dataset.close();
         * 
         * @param disposition open mode
         *
        ******************************************************************************/
        void open(const SDDatasetDisposition disposition);

        
        /*******************************************************************************//**
         * @brief Opens the dataset whose name was specified the constructor.
         * 
         * This method allows opening a dataset with a given open mode and legaltag.
         * 
         * usage example:
         *
         * - SDManager sdmanager;
         * - SDGenericDataset dataset(&sdmanager, "sd://tenant/subproject/data");
         * - dataset.open(SDDatasetDisposition::CREATE, {
         *                      {seismicdrive::api::json::Constants::kLegalTagLabel, "legal-tag"});
         * - dataset.close();
         * 
         * @param disposition open mode
         * @param legaltag the dataset legaltag
         *
        ******************************************************************************/
        void open(const SDDatasetDisposition disposition, const std::string& legaltag);

        
        /*******************************************************************************//**
         * @brief Opens the dataset whose name was specified the constructor.
         * 
         * This method allows opening a dataset with a given open mode and legaltag that has already been locked for writing.
         * 
         * usage example:
         *
         * - SDManager sdmanager;
         * - SDGenericDataset dataset(&sdmanager, "sd://tenant/subproject/data");
         * - dataset.open(SDDatasetDisposition::CREATE, {
         *                      {seismicdrive::api::json::Constants::kLegalTagLabel, "legal-tag"},
         *                      {seismicdrive::api::json::Constants::kWriteIdLabel, "wid"});
         * - dataset.close();
         *
         * @param disposition open mode
         * @param wid is the write opening id. This must be specified if you wnat to open a dataset already locked for write.
         * @param legaltag the dataset legaltag
         *
        ******************************************************************************/
        void open(const SDDatasetDisposition disposition, const std::string& legaltag, const std::string& wid);

        
        /*******************************************************************************//**
         * @brief Main method to open a seismic store dataset
         *
         * This method opens a seismic data dataset in seismic store.
         *
         * The method support different opening dispotion modes:
         *
         *  - CREATE: create a dataset and open it for write
         *  - OVERWRITE: create a dataset and open it for write overriding the existing one.
         *  - READ_WRITE: open an existing dataset for read and write.
         *  - READ_ONLY: open an existing dataset for read only.
         *
         * The method accepts these optional opening arguments (defined in Constants.h);
         *
         *  - kLegalTagLabel: the legal tag,
         *  - kWriteIdLabel: the open write seission id
         *  - kDDMSSeismicMetadataLabel: the seismic storage metadata.
         *  - KPedantic: the pedantic working mode. 
         *               - "enable": the file-metadata, if exist, will be saved automatically during the close. 
         *               - "disable" the file-metadata, if exist, will not be automatically saved during the close.
         *
         * usage example:
         *
         * - SDManager sdmanager;
         * - SDGenericDataset dataset(&sdmanager, "sd://tenant/subproject/data");
         * - dataset.open(SDDatasetDisposition::CREATE, {
         *                      {seismicdrive::api::json::Constants::kLegalTagLabel, "legal-tag"},
         *                      {seismicdrive::api::json::Constants::kWriteIdLabel, "wid"},
         *                      {seismicdrive::api::json::Constants::kDDMSSeismicMetadataLabel, "{\"data\":\"value\"}"} 
         *                      {seismicdrive::api::json::Constants::kPedantic, "enable" || "disable"} });
         * - dataset.close();
         *
         * @param disposition The opening disposition open mode
         * @param args The list of optional arguments
         ******************************************************************************/
        void open(SDDatasetDisposition disposition, const std::unordered_map<std::string, std::string> &args);

        
        /*******************************************************************************//**
         * @brief Close an opened dataset.
         * 
         * This method closes a dataset and marks it as closed. File must be opened.
         *
        ******************************************************************************/
        void close();

        
        /*******************************************************************************//**
         * @brief Gets a dataset url.
         * 
         * This method gets the GCS url of an SDGenericDataset object.
         *
         * @return the dataset GCS url.
        ******************************************************************************/
        std::string getGcsUrl() const;

        
        /*******************************************************************************//**
         * @brief Gets the dataset type.
         * 
         * This method gets the dataset type.
         *
         * @return the dataset type.
        ******************************************************************************/
        std::string getType() const;

        
        /*******************************************************************************//**
         * @brief Gets the legal-tag.
         * 
         * This method gets the legal-tag.
         *
         * @return the legal-tag.
        ******************************************************************************/
        std::string getLegalTag() const;


        /*******************************************************************************//**
         * @brief Determines whether a block of data exists.
         * 
         * This method determines whether a block of data (specified with a block name) exists.
         *
         * @param blocknum is the number of the block
         *
         * @return true if the block exists, otherwise false.
        ******************************************************************************/
		bool blockExists(int blocknum) const;


        /*******************************************************************************//**
         * @brief Determines whether a block of data exists.
         * 
         * This method determines whether a block of data (specified with a block name) exists.
         *
         * @param blockname is the name of the block
         *
         * @return true if the block exists, otherwise false.
        ******************************************************************************/
		bool blockExists(const std::string &blockname) const;


        /*******************************************************************************//**
         * @brief Writes a block of data to GCS.
         * 
         * This method writes a block of data (specified with a block number) with a specified length.
         *
         * @param blocknum is the number of the block (keep it sequential 0...n-1)
         * @param data is the block data to write
         * @param len is the size in byte of the data to write
         * @param check_and_overwrite is a flag that if set to true will force the system to check if a previous block with the same name exist
         *
        ******************************************************************************/
        void writeBlock(int blocknum, const char *data, std::size_t len, bool check_and_overwrite = false);

        
        /*******************************************************************************//**
         * @brief Read a block of data from GCS 
         * 
         * This method reads a block of data specified by the block number.
         * It expects the size of the data to read in bytes.
         * This method does not check the crc32c.
         *
         * @param blocknum should be in the range 0..getBlockNum()-1
         * @param data is a buffer where read data will be saved (pre-allocated)
         * @param offset is the starting reading offset
         * @param numBytes is the size in byte of the data to read
         *
        ******************************************************************************/
        void readBlock(int blocknum, char *data, size_t offset, size_t numBytes);

        
        /*******************************************************************************//**
         * @brief Read a block of data from GCS 
         * 
         * This method reads a block of data specified by the block number.
         * This method does check the crc32c.
         * 
         * @param blocknum should be in the range 0..getBlockNum()-1
         * @param data is a buffer where read data will be saved (pre-allocated)
         * @param len is the param where the reading len will be stored
         *
        ******************************************************************************/
        void readBlock(int blocknum, char *data, size_t &len);

        
        /*******************************************************************************//**
         * @brief Read a block of data from GCS 
         * 
         * This method reads a block of data specified by the block number.
         * It will overwrite any pre-allocated buffers where the data read is to be stored.
         * This method does check the crc32c.         *
         * 
         * @param blocknum should be in the range 0..getBlockNum()-1
         * @param data is a pointer to a buffer where read data will be saved (pre-allocated data will be lost if any)
         * @param len is the param where the reading len will be stored
         *
        ******************************************************************************/
        void readBlock(int blocknum, char **data, size_t &len);

        
        /*******************************************************************************//**
         * @brief Writes a block of data to GCS.
         * 
         * This method writes a block of data (specified with a block name) with a specified length.
         * 
         * @param blockname is the name of the block to write
         * @param data is the block data to write
         * @param len is the size in byte of the data to write
         * @param check_and_overwrite is a flag that if set to true will force the system to check if a previous block with the same name exist
         *
        ******************************************************************************/
        void writeBlock(const std::string &blockname, const char *data, std::size_t len, bool check_and_overwrite = false);

       
        /*******************************************************************************//**
         * @brief Read a block of data from GCS 
         * 
         * This method reads a block of data specified by the block name.
         * It expects the size of the data to read in bytes.
         * This method does not check the crc32c.
         *
         * @param blockname is the name of the block to read
         * @param data is a buffer where read data will be saved (pre-allocated)
         * @param offset is the starting reading offset
         * @param numBytes is the size in byte of the data to read
         *
        ******************************************************************************/
        void readBlock(const std::string &blockname, char *data, size_t offset, size_t numBytes);


        /*******************************************************************************//**
         * @brief Read a block of data from GCS 
         * 
         * This method reads a block of data specified by the block name.
         * This method does check the crc32c.
         * 
         * @param blockname is the name of the block to read
         * @param data is a buffer where read data will be saved (pre-allocated)
         * @param len is the param where the reading len will be stored
         *
        ******************************************************************************/
        void readBlock(const std::string &blockname,  char *data, size_t &len);

        
        /*******************************************************************************//**
         * @brief Read a block of data from GCS 
         * 
         * This method reads a block of data specified by the block number.
         * It will overwrite any pre-allocated buffers where the data read is to be stored.
         * This method does check the crc32c.         *
         * 
         * @param blockname is the name of the block to read
         * @param data is a pointer to a buffer where read data will be saved (pre-allocated data will be lost if any)
         * @param len is the param where the reading len will be stored
         *
        ******************************************************************************/
        void readBlock(const std::string &blockname,  char **data, size_t &len);

        
        /*******************************************************************************//**
        * @brief Gets the size of a block 
        *
        *  This method is an accessor used to get the size of a block in bytes given the block number.   
        * 
        *  @param blocknum should be in the range 0..getBlockNum()-1
        *  
        *  @return the size of the block number blocknum
        ******************************************************************************/
        long long getBlockSize(int blocknum);

        
        /*******************************************************************************//**
        * @brief Gets the size of a block 
        *
        *  This method is an accessor used to get the size of a block in bytes given the block name.   
        * 
        *  @param blockname is the name of the block
        *  
        *  @return the size of the block named blockname
        ******************************************************************************/
        long long getBlockSize(const std::string &blockname);


        /*******************************************************************************//**
        * @brief Gets the sizes of a list of blocks
        *
        *  This method is an accessor used to get the size of a list of blocks in bytes given a vector of their names.   
        * 
        *  @param blockNames is the list of blocks name
        *  
        *  @return the sizes of the blocks named in the vector blockNames
        ******************************************************************************/
        std::vector<long long> getBlocksSize(const std::vector<std::string> &blockNames);

        
        /*******************************************************************************//**
        * @brief Deletes a given block
        *
        *  This method is deletes a block given its name.
        *  If the object does not exist, this method does nothing.   
        * 
        *  @param blockName is the name of the block to delete
        *  
        ******************************************************************************/
        void deleteBlock(const std::string &blockName);

        
        /*******************************************************************************//**
        * @brief Gets the number of blocks
        *
        *  This method is an accessor used to get the block number.   
        * 
        *  @return the number of blocks.
        ******************************************************************************/
        uint64_t getBlockNum();

        
        /*******************************************************************************//**
        * @brief Get the dataset size
        *
        *  This method gets the dataset size, which is the total size of all blocks in the dataset.   
        * 
        *  @return the dataset size.
        ******************************************************************************/
        uint64_t getSize();

        
        /*******************************************************************************//**
         * @brief sets the number of a block
         * 
         * This method sets the number of a block directly to the given number.
         *
         * @param blockNum is the number to be assigned to the block.
         *
        ******************************************************************************/
        void setBlockNum(uint64_t blockNum);

        
        /*******************************************************************************//**
         *
         * @brief Sets the dataset size
         *
         * This method sets the size of a dataset to the given number.
         * 
         * @param size is the size to be assigned to the dataset.
         *
        ******************************************************************************/
        void setSize(uint64_t size);

        
        /*******************************************************************************//**
         * @brief Checks if the user have read access permission on current dataset
         * 
         * This method checks if the user have read access permission on current dataset
         *
         * @return true if the user has read access, and false otherwise.
        ******************************************************************************/
        bool checkReadAccess() const;

        
        /*******************************************************************************//**
         * @brief Checks if the user have write access permission on current dataset
         * 
         * This method checks if the user have write access permission on current dataset
         *
         * @return true if the user has write access, and false otherwise.
        ******************************************************************************/
        bool checkWriteAccess() const;

        
        /*******************************************************************************//**
         * @brief Checks if the user have delete access permission on current dataset
         * 
         * This method checks if the user have delete access permission on current dataset
         *
         * @return true if the user has delete access, and false otherwise.
        ******************************************************************************/
        bool checkDeleteAccess() const;

        
        /*******************************************************************************//**
         * @brief Adds user-defined metadata to the dataset
         *
         * This method adds the user-defined metadata passed here to the current dataset.
         * 
         * @param metadata is the json stringify metadata
        ******************************************************************************/
        void setMetaData(const std::string &metadata) const;

        
        /*******************************************************************************//**
         * @brief Gets the user-defined metadata of the current dataset. 
         * 
         * This method is an accessor used to get the user-defined metadata from the current dataset
         *
         * @return the stringify json metadata of the current dataset
        ******************************************************************************/
        std::string getMetaData() const;

        
        /*******************************************************************************//**
         * @brief Adds seismic metadata to the dataset
         * 
         * This method can be use to set the seismic metadata field in the dataset's JSON
         *
         * usage example:
         *
         * SDManager sdmanager;
         * SDGenericDataset dataset(&sdmanager, "sd://tenant/subproject/data");
         * dataset.open(SDDatasetDisposition::READ_WRITE);
         * dataset.setSeismicMeta("{\"description\":\"\"}");
         * dataset.close();
         *
         * @param seismicmeta is the json stringify seismic metadata. The schema for seismic meta can be found at https://developer.delfi.slb.com/solutions/dataecosystem/tutorials/storageservice
         *
         * @throw SDExceptionDatasetError Invalid JSON or seismicmeta field does not exist after patch request
        ******************************************************************************/
        void setSeismicMeta(const std::string &seismicmeta);

        
        /*******************************************************************************//**
          * @brief Gets the seismic metadata from the dataset
          *
          * This method can be used to retrieve the seismic metadata field from the dataset's JSON
          *
          * usage example:
          *
          * SDManager sdmanager;
          * SDGenericDataset dataset(&sdmanager, "sd://tenant/subproject/data");
          * dataset.open(SDDatasetDisposition::READ_ONLY);
          * auto smeta = dataset.getSeismicMeta();
          * dataset.close()
          *
          * @return the stringify json seismic metadata
        ******************************************************************************/
        std::string getSeismicMeta() const;

        
        /*******************************************************************************//**
        * @brief Gets the dataset coherency tag
        *
        * Returns the CTag for the dataset that is cached on the client side, i.e. the
        * value the tag has on the last explicit call to open() or refreshDatsetMetadata().
        * There is no check to see whether the cache is stale. The method has very low cost.
        *
        * usage example:
        *
        * - SDManager sdmanager;
        * - SDGenericDataset dataset(&sdmanager, "sd://tenant/subproject/data");
        * - dataset.open(SDDatasetDisposition::READ_ONLY);
        * - auto ctag = dataset.getCTag();
        * - dataset.close();
        *
        * @return the dataset coherency tag
        ******************************************************************************/
        std::string getCTag();

        
        /*******************************************************************************//**
         * @brief Gets the locking session id
         * 
         * This method is an accessor used to get the locking session ID of the current dataset.
         *
         * @return the locking id
        ******************************************************************************/
        std::string getConsistencyID();

        
        /*******************************************************************************//**
         * @brief Gets process number that is locking the dataset
         * 
         * This method is an accessor used to get the process number that is locking the current dataset.
         *              
         * @return the consistency process counter
        ******************************************************************************/
        int getConsistencyCounter();

        
        /*******************************************************************************//**
         * @brief Check dataset coherency tag
         *
         * Return true if the cached tag returned by getCTag() still matches what is stored
         * on the server.
         * Return false if the file still exists but has been updated. In this case,
         * all the other cached data for this file must be assumed stale as well.
         * Raise an exception if the file no longer exists.
         * A file that has been deleted and re-created with the same name is considered "updated",
         * not "missing", and will not raise an exception.
         * Note that the cached CTag will not be updated by this function.
         * The method is somewhat expensive since it incurs a single request to the server.
         * CAVEAT: A file has its CTag updated when it is opened for write.
         * The tag does not change when data blocks are written or when the file is closed.
         * This means there is a race condition if a file is open for read by one client
         * and for write by another.
         *
         * usage example:
         *
         * - SDManager sdmanager;
         * - SDGenericDataset dataset(&sdmanager, "sd://tenant/subproject/data");
         * - dataset.open(SDDatasetDisposition::READ_ONLY);
         * - bool isCtagOk = dataset.checkCTag();
         * - dataset.close();
         *
         * @return true if the dataset ctag match the cached one, false if not.
         ******************************************************************************/
        bool checkCTag();

        
        /*******************************************************************************//**
         * @brief Refresh the dataset metadata
         *
         * Unconditionally refresh the metadata from the SD server. You only need to
         * call this if getCTag() returned false. Calling this method is semantically
         * equivalent to closing the SDGenericDataset instance and opening a new one,
         * but it might be more efficient. In particular, if a file has been deleted and
         * re-created with the same name then neither refresh nor close/re-open
         * will have a problem with that.
         *
         * usage example:
         *
         * - SDManager sdmanager;
         * - SDGenericDataset dataset(&sdmanager, "sd://tenant/subproject/data");
         * - dataset.open(SDDatasetDisposition::READ_ONLY);
         * - dataset.refreshDatsetMetadata();
         * - dataset.close();
         *
         ******************************************************************************/
        void refreshDatsetMetadata();

        
        /*******************************************************************************//**
         * @brief Gets the iterator info
         * 
         * This method gets the info from the dataset's SDGenericDatasetBasicObjectIterator object.
         *
         * @return the Generic Dataset Basic Object Iterator
         */
        SDGenericDatasetBasicObjectIterator getIterator() const;

        
        /*******************************************************************************//**
         * @brief Gets the iterator info
         * 
         * This method gets the info from the dataset's SDGenericDatasetBasicObjectIterator object.
         *
         * @param recursive determines the depth of the search

         * @return the Generic Dataset Basic Object Iterator
         */
        SDGenericDatasetBasicObjectIterator getIterator(bool recursive) const;


        /*******************************************************************************//**
         * @brief Flushes the file metadata
         * 
         * This method flushes the metadata of the object into the dataset.
         *
        ******************************************************************************/
        void flush();

        
        /*******************************************************************************//**
         * @brief Checks if the dataset exist
         *
         * This method checks if the created dataset exists on GCP.
         * 
         * @return true if the dataset exist, false if it does not exist
         *
        ******************************************************************************/
        bool exist() const;

        
        /*******************************************************************************//**
         * @brief Generate a serialized Read Only Dataset Accessor
         * 
         * This method generates read only accessor for the current dataset.
         *
         * @return the serialized ReadOnly Dataset Accessor
        ******************************************************************************/
        std::string getSerializedReadOnlyAccessor() const;

        
        /*******************************************************************************//**
         * @brief Upload a file into a single object.
         * 
         * This method uploads the dataset to GCP as a single object. The dataset must not been open.
         *
         * @param filepath is the absolute path of the file to upload
         * @param legaltag the dataset legaltag
         *
        ******************************************************************************/
        void upload(const std::string& filepath, const std::string& legaltag="") const;

        
        /*******************************************************************************//**
         * @brief Add dataset tags
         *
         * This method can be used to set a list of tags to a seismic store dataset.
         * Tags are just simple strings (not key/value pairs).
         *
         * usage example:
         *
         * - SDManager sdmanager;
         * - SDGenericDataset dataset(&sdmanager, "sd://tenant/subproject/data");
         * - dataset.open(SDDatasetDisposition::READ_WRITE);
         * - dataset.setTags({"TestTag01", "TestTag02", "TestTag03"});
         * - dataset.close();
         *
         * @param tags The list of tags to add to the opened seismic store dataset
         ******************************************************************************/
		void setTags(const std::vector<std::string>& tags) const;

        
        /*******************************************************************************//**
         * @brief Get dataset tags
         *
         * This method can be used to retrieve the list of seismic store dataset tags.
         *
         * usage example:
         *
         * - SDManager sdmanager;
         * - SDGenericDataset dataset(&sdmanager, "sd://tenant/subproject/data");
         * - dataset.open(SDDatasetDisposition::READ_ONLY);
         * - auto tags = dataset.getTags();
         * - dataset.close();
         *
         * @return The list of seismic store dataset tags
         ******************************************************************************/
		std::vector<std::string> getTags() const;

        
        /*******************************************************************************//**
         * @brief Get dataset created date
         *
         * This method can be used to retrieve the dataset creation date.
         *
         * usage example:
         *
         * - SDManager sdmanager;
         * - SDGenericDataset dataset(&sdmanager, "sd://tenant/subproject/data");
         * - dataset.open(SDDatasetDisposition::READ_ONLY);
         * - auto cdate = dataset.getCreatedDate();
         * - dataset.close();
         *
         * @return The dataset created date
         ******************************************************************************/
        std::string getCreatedDate() const;

        /*******************************************************************************//**
         * @brief Set connection parameters
         *
         * This method sets connection parameters for the underlying HTTP connection 
         * to the server.
         *
         * @param context The connection parameters to be used for this dataset
         * 
         * usage example:
         *
         * - HttpContext context;
         * - context.timeoutSecs = 3600;
         * - context.tcpKeepAlive = true;
         * - 
         * - SDManager sdmanager;
         * - SDGenericDataset dataset(&sdmanager, "sd://tenant/subproject/data");
         * - dataset.setHttpContext(&context);
         * - dataset.open(SDDatasetDisposition::READ_ONLY);
         * - auto cdate = dataset.getCreatedDate();
         * - dataset.close();
         *
         ******************************************************************************/
        void setHttpContext(const HttpContext *context = nullptr);

        /*******************************************************************************//**
         * @brief Return the dataset open context
         *
         * This method returns the serialized context of an open dataset (require dataset 
         * to be open). The serialized context can be injected as query parameter in the
         * dataset URI to load the serialized context instead of  generating a new one.
         *
         * usage example:
         *
         * - SDManager sdmanager;
         * - SDGenericDataset dataset01(&sdmanager, "sd://tenant/subproject/data");
         * - dataset01.open(seistore::SDDatasetDisposition::READ_ONLY);
         * - context = dataset01.getSerializedContext();
         * - dataset01.close();
         * 
         * - SDGenericDataset dataset02(&sdmanager, "sd://tenant/subproject/data?context=" + context);
         * - // this will load the context (bypass seistore calls)
         * - dataset02.open(seistore::SDDatasetDisposition::READ_ONLY);
         * - dataset02.readBlock("0", const_cast<char*>(res.c_str()), 0, 4);
         * - dataset02.close();
         *
         ******************************************************************************/
        std::string getSerializedContext();

        /*******************************************************************************//**
         * @brief Set the readonly mode for a dataset
         *
         * This method set the dataset as readonly if the input parameter "readonly" is true
         *
         * usage example:
         *
         * - SDManager sdmanager;
         * - SDGenericDataset dataset01(&sdmanager, "sd://tenant/subproject/data");
         * - dataset01.open(seistore::SDDatasetDisposition::READ_WRITE); // or READ_ONLY
         * - dataset01.setReadonlyMode(true);
         * - dataset01.close();
         *
         ******************************************************************************/
        void setReadonlyMode(bool readonly);

    private:

		#ifdef _MSC_VER
    		#pragma warning(push)
    		#pragma warning(disable: 4251)
		#endif

			class Impl;

			std::unique_ptr<Impl> _impl;

		#ifdef _MSC_VER
		    #pragma warning(pop)
		#endif

        friend class SDGenericDatasetTest;
    };
}

#endif //SDAPI_SDGENERICDATASET_H
