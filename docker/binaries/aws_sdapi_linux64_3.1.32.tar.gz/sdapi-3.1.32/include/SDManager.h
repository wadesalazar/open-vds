// ============================================================================
// Copyright 2017-2020, Schlumberger
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// ============================================================================

#ifndef SDAPI_SDMANAGER_H
#define SDAPI_SDMANAGER_H

#include "DLL_EXPORT.h"

#include <cstdint>
#include <string>
#include <memory>

namespace seismicdrive {

    /*******************************************************************************//**
     * @class SDManager SDManager.h
     *
     * @brief Seismic Drive Manager class.
     * 
     * This class will manage url and apikey for the sesimic-drive service, authentication providers and gcsaccessors cache.
     *
    ******************************************************************************/
    class DLL_PUBLIC SDManager {

    public:

        /*******************************************************************************//**
         * @brief Constructor. 
         * 
         * If executed without parameters it will try to load the seismic-drive service url and apikey from the enviroment (SDURL, SDAPIKEY).
         *
         * @param sdurl is the url of the seismic-drive service.
         * @param sdapikey is the api key of the seismic-drive service.
         * @param logging enable the sdapi debug log (set it to 1 to enable it)
        ******************************************************************************/
        SDManager(const std::string& sdurl="", const std::string& sdapikey="", const int16_t logging=0);

        /*******************************************************************************//**
         * @brief Destructor.
         *
         * If the file is opened for writing (not READ_ONLY), it wll be closed.
        ******************************************************************************/
        ~SDManager();

        /*******************************************************************************//**
        * @brief Move Constructor.
        *
        *  This contructor moves the SDManager object from 
        *  the source to the new object and destroy the source object. 
        * 
        ******************************************************************************/
        SDManager(SDManager &&sdsm) noexcept;

        /*******************************************************************************//**
        * @brief Move Assignment Operator.
        *
        *  Same functionality as the move constructor. 
        * 
        ******************************************************************************/
        SDManager &operator=(SDManager &&sdsm) noexcept;

        /*******************************************************************************//**
        * @brief Copy Constructor.
        *
        *  This contructor makes a copy of the SDManager object from 
        *  the source to the new object without modifying the source object. 
        * 
        ******************************************************************************/
        SDManager(const SDManager &op);

        /*******************************************************************************//**
        * @brief Copy Assignment Operator.
        *
        *  Same functionality as the copy constructor. 
        * 
        ******************************************************************************/
        SDManager &operator=(const SDManager &op);

        /*******************************************************************************//**
         * @brief Authentication provider from impersonation token. 
         * 
         * If the impersonation_token param is not specified, it will try to load it from the enviroment (AUTH_TOKEN)
         * 
         * @param impersonation_token is the impersonation token
        ******************************************************************************/
        void setAuthProviderFromImpToken(const std::string& impersonation_token="");

        /*******************************************************************************//**
         * @brief Authentication provider from string. 
         * 
         * This method will always provide the authentication token provided using the idtoken parameter.
         * 
         * @param idtoken is the credential token
        ******************************************************************************/
        void setAuthProviderFromString(const std::string& idtoken);

        /*******************************************************************************//**
         * @brief gets an ID token. 
         * 
         * This method gets an authentication ID token.
         * 
         * @return an ID token.
        ******************************************************************************/
        std::string getIDToken() const;

        /*******************************************************************************//**
         * @brief gets the url of seismic store svc. 
         * 
         * This method gets the latest url of the seismic store service endpoint.
         * 
         * @return the url of the seismic-drive service.
        ******************************************************************************/
        std::string getSDUrl() const;

        /*******************************************************************************//**
         * @brief gets the API Key of seismic store svc. 
         * 
         * This method gets the API Key of the seismic store service endpoint.
         * 
         * @return the api key of the seismic-drive service.
        ******************************************************************************/
        std::string getSDApiKey() const;

        /*******************************************************************************//**
         * @brief Serialize the SDManager object
         * 
         * This method serialize the SDManager object and returns the serialized string version.
         *
         * @return a serialized version of the SDManager object
        ******************************************************************************/
        std::string serialize() const;

        /*******************************************************************************//**
         * @brief Creates an SDManager object.
         * 
         * This method creates an SDManager instance from a serialized string SDManager object.
         *
         * @param sd_manager_serialized is the serialized SDManager object
         * 
         * @return a deserialized SDManager
        ******************************************************************************/
        static SDManager* create(const std::string& sd_manager_serialized);

        /*******************************************************************************//**
         * @brief Sets the log status
         * 
         * This method sets the sdapi debug log status.
         *
         * @param status is the log status (true to enable it | false to disable it)
        ******************************************************************************/
        void setLogStatus(const bool status);


        /*******************************************************************************//**
         * @brief gets the log status
         * 
         * This method checks the sdapi debug log status.
         *
         * @return the sdapi log status
        ******************************************************************************/
        bool getLogStatus() const;

        /*******************************************************************************//**
         * @brief gets major version number
         * 
         * This method returns the sdapi major version number.
         * 
         * @return the sdapi major version number
        ******************************************************************************/
        uint_least16_t getVersionMajor() const;

        /*******************************************************************************//**
         * @brief gets minor version number
         * 
         * This method returns the sdapi minor version number.
         * 
         * @return the sdapi minor version number
        ******************************************************************************/
        uint_least16_t getVersionMinor() const;

        /*******************************************************************************//**
         * @brief gets version patch number
         * 
         * This method returns the sdapi version patch number.
         * 
         * @return the sdapi version patch number
        ******************************************************************************/
        uint_least16_t getVersionPatch() const;

        /*******************************************************************************//**
         * @brief gets version
         * 
         * This method returns the sdapi version as a string.
         * 
         * The format is major.minor.patch, e.g. "2.7.1"
         *
         * @return the sdapi version
        ******************************************************************************/
        std::string getVersion() const;

    private:

		#ifdef _MSC_VER
    		#pragma warning(push)
    		#pragma warning(disable: 4251)
		#endif

			class Impl;

			std::unique_ptr<Impl> _impl;

		#ifdef _MSC_VER
		    #pragma warning(pop)
		#endif

        friend class SDDataset;
        friend class SDReadOnlyGenericDatasetAccessor;
        friend class SDManagerImplTest;
    };
}


#endif //SDAPI_SDMANAGER_H
