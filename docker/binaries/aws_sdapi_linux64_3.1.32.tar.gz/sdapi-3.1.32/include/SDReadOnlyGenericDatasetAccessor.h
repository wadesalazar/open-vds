// ============================================================================
// Copyright 2017-2020, Schlumberger
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// ============================================================================

#ifndef SDAPI_SDREADONLYGENERICDATASETACCESSOR_H
#define SDAPI_SDREADONLYGENERICDATASETACCESSOR_H

#include "DLL_EXPORT.h"
#include <memory>
#include <string>

namespace seismicdrive {

    /*******************************************************************************//**
     * @class SDReadOnlyGenericDatasetAccessor SDReadOnlyGenericDatasetAccessor.h
     *
     * @brief This class represents a generic dataset in GCP that is read only mode.
     * 
     * This class is a Generic ReadOnly Dataset class to to read gcs objects as sequential(0...n-1) file blocks.
     *
    ******************************************************************************/
   
    class DLL_PUBLIC SDReadOnlyGenericDatasetAccessor {

    public:

   	    /*******************************************************************************//**
         *
         * @brief Constructor
         *
         * @param ss is the serialized SDReadOnlyGenericDataset object. The serialized object can be generated through the SDGeneriDataset class
        ******************************************************************************/
        SDReadOnlyGenericDatasetAccessor(const std::string &ss);

   	    /*******************************************************************************//**
         * Destructor.
         *
         * If the file is opened for writing (not READ_ONLY), it will be closed.
         *
        ******************************************************************************/
        ~SDReadOnlyGenericDatasetAccessor();

        /*******************************************************************************//**
        * @brief Move Constructor.
        *
        *  This contructor moves the SDReadOnlyGenericDatasetAccessor object from 
        *  the source to the new object and destroy the source object. 
        * 
        ******************************************************************************/
        SDReadOnlyGenericDatasetAccessor(SDReadOnlyGenericDatasetAccessor &&rhs) noexcept;

        /*******************************************************************************//**
        * @brief Move Assignment Operator.
        *
        *  Same functionality as the move constructor. 
        * 
        ******************************************************************************/
        SDReadOnlyGenericDatasetAccessor &operator=(SDReadOnlyGenericDatasetAccessor &&rhs) noexcept;

        /*******************************************************************************//**
        * @brief Copy Constructor.
        *
        *  This contructor makes a copy of the SDReadOnlyGenericDatasetAccessor object from 
        *  the source to the new object without modifying the source object. 
        * 
        ******************************************************************************/
        SDReadOnlyGenericDatasetAccessor(const SDReadOnlyGenericDatasetAccessor &rhs) = delete;

        /*******************************************************************************//**
        * @brief Copy Assignment Operator.
        *
        *  Same functionality as the copy constructor. 
        * 
        ******************************************************************************/
        SDReadOnlyGenericDatasetAccessor &operator=(const SDReadOnlyGenericDatasetAccessor &rhs) = delete;

        
        /*******************************************************************************//**
         * @brief Read a block of data from GCS 
         * 
         * This method reads a block of data specified by the block number.
         * It expects the size of the data to read in bytes.
         *
         * @param blocknum should be in the range 0..getBlockNum()-1
         * @param data is a buffer where read data will be saved (pre-allocated)
         * @param offset is the starting reading offset
         * @param numBytes is the size in byte of the data to read
         *
        ******************************************************************************/
        void readBlock(int blocknum, char *data, size_t offset, size_t numBytes);

        
        /*******************************************************************************//**
         * @brief Read a block of data from GCS 
         * 
         * This method reads a block of data specified by the block number.
         * 
         * @param blocknum should be in the range 0..getBlockNum()-1
         * @param data is a buffer where read data will be saved (pre-allocated)
         * @param len is the param where the reading len will be stored
         *
        ******************************************************************************/
        void readBlock(int blocknum, char *data, size_t len);

       
       /*******************************************************************************//**
         * @brief Read a block of data from GCS 
         * 
         * This method reads a block of data specified by the block name.
         * It expects the size of the data to read in bytes.
         *
         * @param blockname is the name of the block to read
         * @param data is a buffer where read data will be saved (pre-allocated)
         * @param offset is the starting reading offset
         * @param numBytes is the size in byte of the data to read
        ******************************************************************************/
        void readBlock(const std::string &blockname, char *data, size_t offset, size_t numBytes);

        /*******************************************************************************//**
         * @brief Read a block of data from GCS 
         * 
         * This method reads a block of data specified by the block name.
         * 
         * @param blockname is the name of the block to read
         * @param data is a buffer where read data will be saved (pre-allocated)
         * @param len is the param where the reading len will be stored
        ******************************************************************************/
        void readBlock(const std::string &blockname, char *data, size_t len);


        /*******************************************************************************//**
        * @brief Gets the size of a block 
        *
        *  This method is an accessor used to get the size of a block in bytes given the block number.   
        * 
        *  @param blocknum should be in the range 0..getBlockNum()-1
        *  
        *  @return the size of the block number blocknum
        ******************************************************************************/
        long long getBlockSize(int blocknum);

        
        /*******************************************************************************//**
        * @brief Gets the size of a block 
        *
        *  This method is an accessor used to get the size of a block in bytes given the block name.   
        * 
        *  @param blockname is the name of the block
        *  
        *  @return the size of the block named blockname
        ******************************************************************************/
        long long getBlockSize(const std::string &blockname);


    private:

		#ifdef _MSC_VER
    		#pragma warning(push)
    		#pragma warning(disable: 4251)
		#endif

			class Impl;

			std::unique_ptr<Impl> _impl;

		#ifdef _MSC_VER
    		#pragma warning(pop)
		#endif

        friend class SDReadOnlyGenericDatasetTest;

    };

}

#endif // SDAPI_SDREADONLYGENERICDATASETACCESSOR_H
