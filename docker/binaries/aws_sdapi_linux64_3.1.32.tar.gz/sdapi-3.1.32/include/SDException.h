// ============================================================================
// Copyright 2017-2020, Schlumberger
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// ============================================================================

#ifndef SDAPI_SDEXCEPTION_H
#define SDAPI_SDEXCEPTION_H

#include "DLL_EXPORT.h"

#include <stdexcept>

namespace seismicdrive {

#ifdef _MSC_VER
    #pragma warning(push)
    #pragma warning(disable: 4275)
#endif

	/*******************************************************************************//**
    *  This structure is responsible for throwing a general expection as a runtime error
    ******************************************************************************/
    struct DLL_PUBLIC SDException: public std::runtime_error {

#ifdef _MSC_VER
    #pragma warning(pop)
#endif

        /*******************************************************************************//**
        * @brief throws a general expection as a runtime error
        *
        *  This method is the default exception that 
        *  seismic store throws.  
        *
        *  @param desc is the error description.
        *  @return Void.
        ******************************************************************************/
        SDException(const std::string desc);
    };


    /*******************************************************************************//**
    *  This structure is responsible for throwing a Value Error expection as a runtime error
    ******************************************************************************/
    struct DLL_PUBLIC SDExceptionValueError: public SDException {

        /*******************************************************************************//**
        * @brief throws a value error expection as a runtime error
        *
        *  This method is a more detailed exception that 
        *  seismic store throws. This exception is thrown
        *  when there is a problem with the object you are trying
        *  to assign the value to.  
        *
        *  @param desc is the error description.
        *  @return Void.
        ******************************************************************************/
        SDExceptionValueError(std::string desc);
    };


    /*******************************************************************************//**
    *  This structure is responsible for throwing an AuthProvider expection as a runtime error
    ******************************************************************************/
    struct DLL_PUBLIC SDExceptionAuthProviderError: public SDException {

        /*******************************************************************************//**
        * @brief throws an authentication provider expection as a runtime error
        *
        *  This method is a more detailed exception that 
        *  seismic store throws. This exception is thrown
        *  when there is a problem with the user authentication. 
        *
        *  @param desc is the error description.
        *  @return Void.
        ******************************************************************************/
        SDExceptionAuthProviderError(std::string desc);
    };


    /*******************************************************************************//**
    *  This structure is responsible for throwing a Seismic Store Accessor expection as a runtime error
    ******************************************************************************/
    struct DLL_PUBLIC SDExceptionSDAccessorError: public SDException {

        /*******************************************************************************//**
        * @brief throws a seismic store accessor expection as a runtime error
        *
        *  This method is a more detailed exception that 
        *  seismic store throws. This exception is thrown
        *  when there is a problem with accessing an object. 
        *  The problem is on seismic store level (layer above GCS). 
        *
        *  @param desc is the error description.
        *  @return Void.
        ******************************************************************************/
        SDExceptionSDAccessorError(std::string desc);
    };


    /*******************************************************************************//**
    *  This structure is responsible for throwing a Google Cloud Storage Accessor expection as a runtime error
    ******************************************************************************/
    struct DLL_PUBLIC SDExceptionGCSAccessorError: public SDException {

        /*******************************************************************************//**
        * @brief throws a google cloud storage accessor expection as a runtime error
        *
        *  This method is a more detailed exception that 
        *  seismic store throws. This exception is thrown
        *  when there is a problem with accessing an object.
        *  This problem is on google cloud storage level (layer under SD). 
        *
        *  @param desc is the error description.
        *  @return Void.
        ******************************************************************************/
        SDExceptionGCSAccessorError(std::string desc);
    };


    /*******************************************************************************//**
    *  This structure is responsible for throwing a Dataset expection as a runtime error
    ******************************************************************************/
    struct DLL_PUBLIC SDExceptionDatasetError: public SDException {

        /*******************************************************************************//**
        * @brief throws a dataset expection as a runtime error
        *
        *  This method is a more detailed exception that 
        *  seismic store throws. This exception is thrown
        *  when there is a problem with the dataset itself. 
        *
        *  @param desc is the error description.
        *  @return Void.
        ******************************************************************************/
        SDExceptionDatasetError(std::string desc);
    };


    /*******************************************************************************//**
    *  This structure is responsible for throwing a Context Expire expection as a runtime error
    ******************************************************************************/
    struct DLL_PUBLIC SDExceptionContextExpired: public SDException {

        /*******************************************************************************//**
        * @brief throws a context expire expection as a runtime error
        *
        *  This method is a more detailed exception that 
        *  seismic store throws. This exception is thrown
        *  when the dataset context is expired.
        *
        *  @param desc is the error description.
        *  @return Void.
        ******************************************************************************/
        SDExceptionContextExpired(std::string desc);
    };

    /*******************************************************************************//**
    *  This kind of exception is thrown if a dataset context was created by an sdapi 
    *  instance which uses an incompatible (newer) context serializing schema.
    ******************************************************************************/
    struct DLL_PUBLIC SDExceptionContextVersionTooNew: public SDException {

        /*******************************************************************************//**
        * @brief This kind of exception is thrown if a dataset context was created by an sdapi 
        *  instance which uses an incompatible (newer) context serializing schema.
        *
        *  @param desc is the error description.
        ******************************************************************************/
        SDExceptionContextVersionTooNew(std::string desc);
    };

    /*******************************************************************************//**
    *  This kind of exception is thrown if a dataset context path does not match the
    *  dataset path.
    ******************************************************************************/
    struct DLL_PUBLIC SDExceptionContextPathNoMatch: public SDException {

        /*******************************************************************************//**
        * @brief This kind of exception is thrown if a dataset context path does not match the
        *  dataset path
        *
        *  @param desc is the error description.
        ******************************************************************************/
        SDExceptionContextPathNoMatch(std::string desc);
    };

    /*******************************************************************************//**
    * This kind of exception serves as a base class for storage 
    * exceptions, e.g. SDExceptionAzureStorageError.
    * 
    * They are thrown if there is a problem with accessing an object in cloud storage.
    ******************************************************************************/
    struct DLL_PUBLIC SDExceptionStorageError: public SDException {
        /*******************************************************************************//**
        * @brief This kind of exception is thrown if there is a problem with accessing 
        * an object in cloud storage.
        * 
        * This problem is at the cloud storage level (layer under SD).
        *
        * @param desc is the error description.
        ******************************************************************************/
        SDExceptionStorageError(std::string desc);
    };

    /*******************************************************************************//**
    * This kind of exception is thrown if there is a problem with accessing an 
    * object in Azure storage.
    ******************************************************************************/
    struct DLL_PUBLIC SDExceptionAzureStorageError: public SDExceptionStorageError {
        /*******************************************************************************//**
        * @brief This kind of exception is thrown if there is a problem with accessing 
        * an object in Azure storage.
        * 
        * This problem is at the Azure storage level (layer under SD).
        *
        * @param desc is the error description.
        ******************************************************************************/
        SDExceptionAzureStorageError(std::string desc);
    };

    /*******************************************************************************//**
    *  This structure is responsible for throwing an Internal expection as a runtime error
    ******************************************************************************/
    struct DLL_PUBLIC SDExceptionInternalError: public SDException {
        /*******************************************************************************//**
        * @brief throws an internal expection as a runtime error
        *
        *  This method is a more detailed exception that 
        *  seismic store throws. This exception is thrown
        *  when there is an internal problem with Seismic Store. 
        *
        *  @param desc is the error description.
        *  @return Void.
        ******************************************************************************/
        SDExceptionInternalError(std::string desc);
    };

}

#endif
