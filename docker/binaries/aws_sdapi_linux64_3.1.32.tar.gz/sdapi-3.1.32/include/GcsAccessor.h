// ============================================================================
// Copyright 2017-2020, Schlumberger
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// ============================================================================

#ifndef SDAPI_GCSACCESSOR_H
#define SDAPI_GCSACCESSOR_H

#include "HttpContext.h"

#include "DLL_EXPORT.h"

#include <memory>
#include <string>
#include <vector>

namespace seismicdrive {

struct HttpContext;
class GcsAccessorImpl;
class BasicObjectInfoIteratorImpl;

// --------------------------------
// BasicObjectInfo
// --------------------------------

class DLL_PUBLIC BasicObjectInfo {

	public:

		BasicObjectInfo() = default;
		~BasicObjectInfo() = default;
		BasicObjectInfo(const BasicObjectInfo& rhs) = default;

		#ifdef _MSC_VER
    		#pragma warning(push)
    		#pragma warning(disable: 4251)
		#endif

			//! Object name
			std::string name;

		#ifdef _MSC_VER
		    #pragma warning(pop)
		#endif

        //! Object size
		long long size;
};

// --------------------------------
// BasicObjectInfoIterator
// --------------------------------

class DLL_PUBLIC BasicObjectInfoIterator {

    public:

        /**
         * Constructor.
         */
		BasicObjectInfoIterator(); // for keep same interface with previous version

        /**
         * Destructor.
         */
		~BasicObjectInfoIterator();

		/**
         * Call to see if more objects are available
         */
		bool hasNext();

		/**
         * Returns next object
         */
		BasicObjectInfo next();

    private:

        friend class GcsAccessorImpl;
        BasicObjectInfoIterator(BasicObjectInfoIteratorImpl *impl);

		#ifdef _MSC_VER
    		#pragma warning(push)
    		#pragma warning(disable: 4251)
		#endif

			std::shared_ptr<BasicObjectInfoIteratorImpl> _impl;

		#ifdef _MSC_VER
		    #pragma warning(pop)
		#endif

        friend class GcsAccessorTest;
};

// --------------------------------
// GcsContext
// --------------------------------

struct GcsContext : public HttpContext {
};

// --------------------------------
// GcsAccessorInterface
// --------------------------------

struct GcsAccessorIF {
    virtual bool objectExists(const std::string &gcsObjectPath, const GcsContext* pContext = nullptr) = 0;
    virtual std::string objectAttribute(const std::string &gcs_path, const std::string &attribute_name, const GcsContext* pContext = nullptr) = 0;
    virtual long long objectSize(const std::string &gcs_path, const GcsContext* pContext = nullptr) = 0;
    virtual std::string objectDate(const std::string &gcs_path, const GcsContext* pContext = nullptr) = 0;
    virtual void uploadObject(const std::string &pathName, const void *data, size_t len, const GcsContext* pContext = nullptr) = 0;
    virtual void downloadObject(const std::string &gcs_path, void *data, size_t offset, size_t len, const GcsContext* pContext = nullptr) = 0;
    virtual void downloadObject(const std::string &gcs_path, void *data, size_t& len, const GcsContext* pContext = nullptr) = 0;
    virtual void downloadObject(const std::string &gcs_path, void **data, size_t& len, const GcsContext* pContext = nullptr) = 0;
    virtual void deleteObject(const std::string &gcs_path, const GcsContext* pContext = nullptr) = 0;
    virtual void updateMetadata(const std::string &gcs_path, const std::vector<std::pair<std::string, std::string> > &keyValues, const GcsContext* pContext = nullptr) = 0;
    virtual void getMetadata(const std::string &gcs_path, std::vector<std::pair<std::string, std::string> > &keyValues, const GcsContext* pContext = nullptr) = 0;
    virtual std::vector<long long> objectsSize(const std::vector<std::string> &gcs_paths, const GcsContext* pContext = nullptr) = 0;
    virtual void deleteObjects(const std::vector<std::string> &gcs_paths, const GcsContext* pContext = nullptr) = 0;
    virtual void setLoggingMode(int mode) = 0;
    virtual void uploadObject(const std::string &gcs_path, const std::string &file_name, const GcsContext* pContext = nullptr) = 0;
    virtual void composeObjects(const std::string &gcs_dest_path, const std::vector<std::string> &gcs_source_paths, const GcsContext* pContext = nullptr) = 0;
    virtual BasicObjectInfoIterator getIterator(const std::string &gcs_path, const GcsContext* pContext = nullptr) = 0;
    virtual std::vector<std::pair<std::string, uint64_t>> ls(const std::string& gcs_path, const GcsContext* pContext = nullptr) = 0;
    virtual void lockObject(const std::string &gcs_path, const GcsContext* pContext = nullptr) = 0;
    virtual void unlockObject(const std::string &gcs_path, const GcsContext* pContext = nullptr) = 0;
    virtual void waitLockObject(const std::string &gcs_path, const GcsContext* pContext = nullptr) = 0;
};


/*******************************************************************************//**
    * @class GcsAccessor GcsAccessor.h
    *
    * @brief This class is an accessor for the GCS objects.
    * 
    * This class handles objects located in a given GCS path.
    *
******************************************************************************/

class DLL_PUBLIC GcsAccessor: public GcsAccessorIF {

public:

    /* CTOR */

    /*******************************************************************************//**
    * @brief Default constructor.
    *
    *  This contructor creates a GcsAccessor object and 
    *  initialize the dataset info. 
    * 
    ******************************************************************************/
    GcsAccessor();

    /*******************************************************************************//**
     * @brief Parameterized contructor
     * 
     * This constructor initializes the accessor object using user-defined arguments.
     *
     * @param auth_provider is the auth provider
     * @param sdresource is the seismic drive subproject resource (optional if the auth provider is a google default one)
     * @param readonly define the access policy (read or readwrite)
    ******************************************************************************/
	GcsAccessor(void* auth_provider, const std::string& sdresource = "", const bool readonly = false);

    
    /*******************************************************************************//**
    * @brief Copy Constructor.
    *
    *  This contructor makes a copy of the GcsAccessor object from 
    *  the source to the new object without modifying the source object. 
    * 
    ******************************************************************************/
    GcsAccessor(const GcsAccessor& rhs) = delete;


    /*******************************************************************************//**
    * @brief Copy Assignment Operator.
    *
    *  Same functionality as the copy constructor. 
    * 
    ******************************************************************************/
    GcsAccessor& operator= ( const GcsAccessor& ) = delete;


    /*******************************************************************************//**
    * @brief Move Constructor.
    *
    *  This contructor moves the GcsAccessor object from 
    *  the source to the new object and destroy the source object. 
    * 
    ******************************************************************************/
    GcsAccessor(GcsAccessor && op) noexcept;


    /*******************************************************************************//**
    * @brief Move Assignment Operator.
    *
    *  Same functionality as the move constructor. 
    * 
    ******************************************************************************/
    GcsAccessor& operator=(GcsAccessor && op) noexcept;


    /*******************************************************************************//**
     * @brief Destructor
     * 
     * This destructor deletes the GcsAccessor object and 
     *  free up the memory after it goes out of scope.
     * 
    ******************************************************************************/
    ~GcsAccessor();

    /* Methods */

    /*******************************************************************************//**
     * @brief Checks if an object exists
     * 
     * This method checks if an object exists on GCP in a certain path. 
     *
     * @param gcs_path is the gcs URI of the resource
     * @param pContext is the gcs context of the access request
     * 
     * @return true if tge object exists, false if the object not exist
    ******************************************************************************/
	bool objectExists(const std::string &gcs_path, const GcsContext* pContext = nullptr) override;

    /*******************************************************************************//**
     * @brief Retrieves a gcs object attribute
     * 
     * This method gets a GCS attribute given the GCS path and the attribute name
     *
     * @param gcs_path is the gcs URI of the resource object
     * @param attribute_name is the name of one of attributes of the object. See the GCS json api doc for available attributes
     * @param pContext is the gcs context of the access request
     * 
     * @return the value of the attribute as a string
     *
    ******************************************************************************/
    std::string objectAttribute(const std::string &gcs_path, const std::string &attribute_name, const GcsContext* pContext = nullptr) override;

    
    /*******************************************************************************//**
     * @brief Gets the size of an object
     * 
     * This method gets the size of an object in a given GCS path
     *
     * @param gcs_path is the gcs URI of the resource object
     * @param pContext is the gcs context of the access request
     * 
     * @return the size of the object in bytes
    ******************************************************************************/
    long long objectSize(const std::string &gcs_path, const GcsContext* pContext = nullptr) override;


    /*******************************************************************************//**
     * @brief Get the creation date of an object
     * 
     * This method gets the date a GCS object was created given its GCS path
     *
     * @param gcs_path is the gcs URI of the resource object
     * @param pContext is the gcs context of the access request
     * 
     * @return the creation date of the object
    ******************************************************************************/
    std::string objectDate(const std::string &gcs_path, const GcsContext* pContext = nullptr) override;


    /*******************************************************************************//**
     * @brief Upload/Create an object from a buffer
     * 
     * This method creates an object from a given data (buffer) and upload it to GCS.
     *
     * @param gcs_path is the gcs URI of the resource object
     * @param data start of data to store in the object
     * @param len number of bytes to store
     * @param pContext is the gcs context of the access request
    ******************************************************************************/
	void uploadObject(const std::string &gcs_path, const void *data, size_t len, const GcsContext* pContext = nullptr) override;

    /*******************************************************************************//**
     * @brief Download all or part of an object 
     * 
     * This method downloads from a GCS object given the start of the buffer with the wanted offset.
     * This method doesnt check crc32c on partial download
     *
     * @param gcs_path is the gcs URI of the resource object
     * @param data start of data buffer to receive object contents
     * @param offset first byte in the object to return
     * @param len number of bytes to download
     * @param pContext is the gcs context of the access request
    ******************************************************************************/
	void downloadObject(const std::string &gcs_path, void *data, size_t offset, size_t len, const GcsContext* pContext = nullptr) override;

    /*******************************************************************************//**
     * @brief Download an object from gcs 
     * 
     * This method download an object from GCS from start to end.
     * The crc32c is checked on downloaded object.
     *
     * @param gcs_path is the gcs URI of the resource object
     * @param data start of data buffer to receive object contents
     * @param len the read length will be saved/returned in this parameter
     * @param pContext is the gcs context of the access request
    ******************************************************************************/
	void downloadObject(const std::string &gcs_path, void *data, size_t& len, const GcsContext* pContext = nullptr) override;

    /*******************************************************************************//**
     * @brief Download an object from gcs 
     * 
     * This method download an object from gcs by dinamically allocationg the memory of the "data" buffer with the right object size.
     * Memory is allocated in the method and the size will be saved and returned in the len parameter.
     * The crc32c is checked on downloaded object.
     *
     * @param gcs_path is the gcs URI of the resource object
     * @param data start of data buffer to receive object contents
     * @param len the length of the downloaded  object will be saved/returned in the len parameter
     * @param pContext is the gcs context of the access request
    ******************************************************************************/
	void downloadObject(const std::string &gcs_path, void **data, size_t& len, const GcsContext* pContext = nullptr) override;


    /*******************************************************************************//**
     * @brief Delete an object
     * 
     * This method deletes an object from GCS given its GCS path.
     *
     * @param gcs_path is the gcs URI of the resource object to delete
     * @param pContext is the gcs context of the access request
    ******************************************************************************/
	void deleteObject(const std::string &gcs_path, const GcsContext* pContext = nullptr) override;


    /*******************************************************************************//**
     * @brief Update object's metadata.
     * 
     * This method updates the metadata of an object to the given list of key value pairs. 
     *
     * @param gcs_path is the gcs URI of the resource object
     * @param keyValues vector of key / value pairs of metadata
     * @param pContext is the gcs context of the access request
    ******************************************************************************/
	void updateMetadata(const std::string &gcs_path, const std::vector<std::pair<std::string, std::string> > &keyValues, const GcsContext* pContext = nullptr) override;


    /*******************************************************************************//**
     * @brief Get object's metadata
     * 
     * This method retrieves the metadata of a GCS object given its GCS path.
     *
     * @param gcs_path is the gcs URI of the resource object
     * @param keyValues (OUTPUT) vector of key / value pairs of metadata
     * @param pContext is the gcs context of the access request
    ******************************************************************************/
    void getMetadata(const std::string &gcs_path, std::vector<std::pair<std::string, std::string> > &keyValues, const GcsContext* pContext = nullptr) override;

    /*******************************************************************************//**
     * @brief Return sizes of several objects
     * 
     * This method gets the sizes of a list of objects given their GCS paths 
     *
     * @param gcs_paths is a vector of gcs objects URI
     * @param pContext is the gcs context of the access request
     * 
     * @return size of corresponding object or -1
    ******************************************************************************/
    std::vector<long long> objectsSize(const std::vector<std::string> &gcs_paths, const GcsContext* pContext = nullptr) override;

    /*******************************************************************************//**
     * @brief Delete multiple objects. 
     * 
     * This method deletes a list of objects given their GCS paths.
     * It is much faster than multiple calls to deleteObject()
     *
     * @param gcs_paths is a vector of gcs objects URI
     * @param pContext is the gcs context of the access request
    ******************************************************************************/
    void deleteObjects(const std::vector<std::string> &gcs_paths, const GcsContext* pContext = nullptr) override;

    /*******************************************************************************//**
     * @brief Set logging mode
     * 
     * This method controls whether or not the dataset it going to print logs.
     *
     * @param mode : 0 no logging (default), 1 log
    ******************************************************************************/
	void setLoggingMode(int mode) override;

    /*******************************************************************************//**
     * @brief Upload (create) an object from a local file
     * 
     * This method creates an object identical to a local file and upload it to GCS. 
     *
     * @param gcs_path name of object to create
     * @param file_name name of file to be uploaded to object
     * @param pContext is the gcs context of the access request
    ******************************************************************************/
	void uploadObject(const std::string &gcs_path, const std::string &file_name, const GcsContext* pContext = nullptr) override;

    /*******************************************************************************//**
     * @brief Compose multiple objects into a new objects
     * 
     * This method combines several objects given their GCS paths into one object created in the given destination path.
     *
     * @param gcs_dest_path name of the new object to create
     * @param gcs_source_paths names of existing objects to be combined into dest
     * @param pContext is the gcs context of the access request
    ******************************************************************************/
    void composeObjects(const std::string &gcs_dest_path, const std::vector<std::string> &gcs_source_paths, const GcsContext* pContext = nullptr) override;

    /*******************************************************************************//**
     * @brief gets object iterator for objects matching path name
     * 
     * This method searches for objects in the given path and return an iterator to these objects.
     *
     * @param gcs_path is the gcs URI name of the form "gs://<bucket>[/<object prefix>]". Only those objects matching the "<object prefix>/" will be included
     * @param pContext is the gcs context of the access request
    ******************************************************************************/
	BasicObjectInfoIterator getIterator(const std::string &gcs_path, const GcsContext* pContext = nullptr) override;

    /*******************************************************************************//**
     * @brief gets object iterator for objects matching path name
     * 
     * This method searches for objects in the given path and return an iterator to these objects.
     *
     * @param gcs_path is the gcs URI name of the form "gs://<bucket>[/<object prefix>]". Only those objects matching the "<object prefix>/" will be included
     * @param recursive determins the depth of the search
     * @param pContext is the gcs context of the access request
    ******************************************************************************/
	BasicObjectInfoIterator getIterator(const std::string &gcs_path, bool recursive, const GcsContext* pContext = nullptr);

    /*******************************************************************************//**
     * @brief get all objects in a bucket resource
     * 
     * This method takes a GCS path and return a list of all the objects that exists in that path.
     *
     * @param gcs_path is the gcs URI
     * @param pContext is the gcs context of the access request
     * 
     * @return a list of the object names in the given GCS path.
    ******************************************************************************/
    std::vector<std::pair<std::string, uint64_t>> ls(const std::string& gcs_path, const GcsContext* pContext = nullptr) override;

    /*******************************************************************************//**
     * @brief Creates a lock file at a GCS path
     * 
     * This method locks the object located in the given GCS path.
     *
     * @param gcs_path is the gcs URI of the resource object
     * @param pContext is the gcs context of the access request
    ******************************************************************************/
    void lockObject(const std::string & gcs_path, const GcsContext* pContext = nullptr) override;

    /*******************************************************************************//**
     * @brief waits for the lock to be released
     * 
     * This method waits for the lock placed on the object in the gicen GCS path to be released.
     *
     * @param gcs_path is the gcs URI of the resource object
     * @param pContext is the gcs context of the access request
    ******************************************************************************/
    void waitLockObject(const std::string & gcs_path, const GcsContext* pContext = nullptr) override;

    /*******************************************************************************//**
     * @brief Unlock file at a GCS path
     * 
     * This method removes the lock from the object in the given GCS path.
     *
     * @param gcs_path is the gcs URI of the resource object
     * @param pContext is the gcs context of the access request
    ******************************************************************************/
    void unlockObject(const std::string &gcs_path, const GcsContext* pContext = nullptr) override;

    /*******************************************************************************//**
     * @brief Set a default gcs context for access requests
     * 
     * This method sets a default gcs context for access requests.
     *
     * @param pContext is the gcs context of the access request
    ******************************************************************************/
    void setHttpContext(const HttpContext *pContext = nullptr);

    /*******************************************************************************//**
     * @brief get the storage access token for a resource 
     * 
     * This method get the storage access token for a resource
     *
     * @param resourceRef the reference resource  (subproject path string + readonly as "true"/"false");
    ******************************************************************************/
    std::pair<std::string, uint64_t> getCachedStorageAccessToken(const std::string& resourceRef);

    /*******************************************************************************//**
    * @brief set the storage access token for a resource 
    * 
    * This method get the internal storage access token for a specific resource
    *
    * @param resourceRef the reference resource  (subproject path string + readonly as "true"/"false");
    * @param credentials the credentials as <token;expire_time_from_epoch>
    ******************************************************************************/
    void setCachedStorageAccessToken(
        const std::string& resourceRef, std::pair<std::string, uint64_t> credentials);    

    /*******************************************************************************//**
    * @brief return the object children list
    * 
    * This method return the object children list for a specified gcs path prefix
    *
    * @param objPath the reference resource  (gs://bucket/prefix;
    * @param recursiveList true to return the recursive object children list
    * @param nextPageToken continuation token
    * @param result results will be returned in this vector
    * @param pContext is the gcs context of the access request
    ******************************************************************************/
    void getChildren(
        const std::string &objPath, bool recursiveList, std::string *nextPageToken,
        std::vector<BasicObjectInfo> *result, const GcsContext* pContext);


private:

	#ifdef _MSC_VER
    	#pragma warning(push)
    	#pragma warning(disable: 4251)
	#endif

	    std::shared_ptr<GcsAccessorImpl> _impl;

	#ifdef _MSC_VER
	    #pragma warning(pop)
	#endif

    friend class GcsAccessorTest;

};

} // namespace seismicdrive

#endif // SDAPI_GCSACCESSOR_H
