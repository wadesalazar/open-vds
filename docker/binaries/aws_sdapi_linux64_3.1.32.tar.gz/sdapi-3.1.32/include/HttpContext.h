// ============================================================================
// Copyright 2020, Schlumberger
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// ============================================================================

#ifndef HTTP_CONTEXT_H
#define HTTP_CONTEXT_H

#include <cstdint>

namespace seismicdrive {

struct HttpContext {
    // Maximum time in seconds, the access request(like downloadObject, uploadObject,..) is supposed to take.  Abort access if it takes more than 3600 seconds.
    uint32_t timeoutSecs                    {3600};
    // Lowest access transfer speed in bytes per second during lowSpeedTimeSecs below which the transfer aborts. Abort transfer if the transfer speed is slower than 30 bytes per second for a duration of 15 seconds.  Low speed limit option can be disabled by setting lowSpeedLimitBytesPerSec and lowSpeedTimeSecs to 0.
    uint32_t lowSpeedLimitBytesPerSec       {30};
    // Time duration in seconds during which the access transfer speed should be below lowSpeedLimitBytesPerSec for aborting the access request. Abort transfer if the transfer speed is slower than 30 bytes per second for a duration of 15 seconds.  Low speed limit option can be disabled by setting lowSpeedLimitBytesPerSec and lowSpeedTimeSecs to 0.
    uint32_t lowSpeedTimeSecs               {15};
    // Enable re-authorization of credentials on Timeout due to either Access request or low speed limit options.
    bool reauthorizeOnTimeout               {true};
    // Enable TCP Keep Alive probing.
    bool tcpKeepAlive                       {true};
    // Waiting time duration in seconds while the TCP connection is idle before sending Keep Alive probes.
    uint32_t tcpKeepIdle                    {60};
    // Time interval in seconds between sending Keep Alive probes.
    uint32_t tcpKeepIntvl                   {60};
};

} // namespace seismicdrive

#endif // HTTP_CONTEXT_H
